from PIL import Image, ImageDraw, ImageFont
import os

# Tạo icon đơn giản với emoji tomato
sizes = [16, 48, 128]

for size in sizes:
    # Tạo background gradient
    img = Image.new('RGB', (size, size), color='white')
    draw = ImageDraw.Draw(img)
    
    # Vẽ hình tròn màu đỏ (tomato)
    margin = size // 8
    draw.ellipse([margin, margin, size-margin, size-margin], fill='#e53e3e')
    
    # Vẽ lá nhỏ
    if size >= 48:
        leaf_size = size // 6
        draw.ellipse([size//2 - leaf_size//2, margin//2, size//2 + leaf_size//2, margin//2 + leaf_size], fill='#48bb78')
    
    img.save(f'icon{size}.png')
    print(f'Created icon{size}.png')

print('All icons created successfully!')
