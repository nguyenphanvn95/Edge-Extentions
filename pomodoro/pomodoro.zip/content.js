// Content Script - Chặn website khi đang tập trung
let isBlocking = false;
let ultraFocus = false;
let blacklist = [];
let whitelist = [];

// Khởi tạo
initialize();

function initialize() {
  loadBlockedSites();
  
  // Lắng nghe messages từ background
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'updateBlockingState') {
      isBlocking = message.isBlocking;
      ultraFocus = message.ultraFocus;
      
      if (isBlocking) {
        checkAndBlockSite();
      } else {
        removeBlockOverlay();
      }
      
      sendResponse({ success: true });
    }
  });
  
  // Kiểm tra ngay khi load trang
  chrome.runtime.sendMessage({ action: 'getTimerState' }, (response) => {
    if (response && response.isRunning && response.mode === 'work') {
      isBlocking = true;
      checkAndBlockSite();
    }
  });
}

function loadBlockedSites() {
  chrome.storage.local.get(['blacklist', 'whitelist', 'ultraFocus'], (result) => {
    blacklist = result.blacklist || [];
    whitelist = result.whitelist || [];
    ultraFocus = result.ultraFocus || false;
    
    if (isBlocking) {
      checkAndBlockSite();
    }
  });
}

function checkAndBlockSite() {
  const currentDomain = extractDomain(window.location.hostname);
  
  // Kiểm tra nếu site nằm trong blacklist
  const isBlacklisted = blacklist.some(site => 
    currentDomain.includes(site) || site.includes(currentDomain)
  );
  
  // Kiểm tra nếu site nằm trong whitelist
  const isWhitelisted = whitelist.some(site => 
    currentDomain.includes(site) || site.includes(currentDomain)
  );
  
  // Chặn nếu trong blacklist và không trong whitelist
  if (isBlacklisted && !isWhitelisted) {
    showBlockOverlay();
  } else if (isWhitelisted) {
    removeBlockOverlay();
  }
}

function extractDomain(hostname) {
  // Loại bỏ www. và các subdomain
  return hostname.replace(/^www\./, '');
}

function showBlockOverlay() {
  // Kiểm tra nếu overlay đã tồn tại
  if (document.getElementById('pomodoro-block-overlay')) {
    return;
  }
  
  const overlay = document.createElement('div');
  overlay.id = 'pomodoro-block-overlay';
  overlay.className = 'pomodoro-overlay';
  
  const content = `
    <div class="pomodoro-block-content">
      <div class="pomodoro-tomato">🍅</div>
      <h1>Website bị chặn</h1>
      <p>Bạn đang trong phiên tập trung Pomodoro</p>
      <p class="pomodoro-message">
        ${ultraFocus ? 
          '🔥 Chế độ siêu tập trung đang được kích hoạt!' : 
          'Hãy tập trung vào công việc của bạn!'
        }
      </p>
      <div class="pomodoro-tips">
        <p>💡 <strong>Mẹo:</strong></p>
        <ul>
          <li>Tắt thông báo điện thoại</li>
          <li>Chuẩn bị đồ uống trước khi bắt đầu</li>
          <li>Làm việc trong môi trường yên tĩnh</li>
        </ul>
      </div>
      <div class="pomodoro-buttons">
        <button class="pomodoro-btn pomodoro-btn-primary" id="pomodoro-back-btn">
          🔙 Quay lại làm việc
        </button>
        <button class="pomodoro-btn pomodoro-btn-secondary" id="pomodoro-settings-btn">
          ⚙️ Cài đặt
        </button>
      </div>
      <p class="pomodoro-footer">
        Powered by Pomodoro Grande 🍅
      </p>
    </div>
  `;
  
  overlay.innerHTML = content;
  document.body.appendChild(overlay);
  
  // Add event listeners
  document.getElementById('pomodoro-back-btn').addEventListener('click', () => {
    window.history.back();
  });
  
  document.getElementById('pomodoro-settings-btn').addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'openSettings' });
  });
  
  // Ngăn scroll
  document.body.style.overflow = 'hidden';
}

function removeBlockOverlay() {
  const overlay = document.getElementById('pomodoro-block-overlay');
  if (overlay) {
    overlay.remove();
    document.body.style.overflow = '';
  }
}

// Lắng nghe thay đổi storage
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (changes.blacklist || changes.whitelist || changes.ultraFocus) {
    loadBlockedSites();
  }
});
