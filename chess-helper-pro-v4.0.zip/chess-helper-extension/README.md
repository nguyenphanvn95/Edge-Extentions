# Chess.com Move Helper Extension 🤖♟️

Extension Chrome giúp gợi ý nước đi tiếp theo khi chơi cờ trên Chess.com.

## ✨ Tính năng

- **⚠️ Cảnh báo quân bị đe dọa**: Phát hiện và cảnh báo khi quân cờ của bạn đang bị tấn công
- **🎯 Gợi ý tấn công**: Tìm kiếm cơ hội tấn công quân đối thủ
- **♟️ Phát triển quân**: Gợi ý cách phát triển quân hợp lý trong khai cuộc
- **🏰 Chiến thuật cơ bản**: Nhập thành, kiểm soát trung tâm và các chiến thuật cơ bản khác

## 📦 Cài đặt

### Cách 1: Cài đặt từ Developer Mode (Khuyến nghị)

1. **Tải extension**:
   - Download toàn bộ thư mục `chess-helper-extension`

2. **Mở Chrome Extensions**:
   - Mở Google Chrome
   - Vào `chrome://extensions/` hoặc Menu → More Tools → Extensions
   
3. **Bật Developer Mode**:
   - Bật công tắc "Developer mode" ở góc trên bên phải

4. **Load Extension**:
   - Nhấn nút "Load unpacked"
   - Chọn thư mục `chess-helper-extension`
   - Extension sẽ xuất hiện trong danh sách extensions

5. **Ghim Extension** (tùy chọn):
   - Nhấn vào icon puzzle ở thanh công cụ Chrome
   - Tìm "Chess.com Move Helper" và nhấn vào icon ghim

## 🎮 Cách sử dụng

1. **Vào Chess.com**:
   - Truy cập [chess.com/play/online](https://www.chess.com/play/online)
   - Bắt đầu một ván cờ mới

2. **Kích hoạt trợ lý**:
   - Panel trợ lý sẽ tự động xuất hiện ở góc phải màn hình
   - Nhấn nút **"Bật"** để bắt đầu nhận gợi ý

3. **Xem gợi ý**:
   - Các gợi ý sẽ được hiển thị theo thứ tự ưu tiên:
     - 🔴 Màu đỏ: Ưu tiên cao (quân bị đe dọa)
     - 🟡 Màu vàng: Ưu tiên trung bình (cơ hội tấn công)
     - 🔵 Màu xanh: Ưu tiên thấp (phát triển quân)

4. **Tắt trợ lý**:
   - Nhấn nút **"Tắt"** khi không cần gợi ý

## 🎯 Ví dụ gợi ý

Extension sẽ cung cấp các loại gợi ý như:

- **"⚠️ Di chuyển Hậu từ d5 - Quân Hậu đang bị đe dọa!"**
- **"🎯 Tấn công Hậu tại e7 - Cơ hội bắt Hậu đối phương!"**
- **"♟️ Phát triển Mã ra trung tâm - Mã hoạt động tốt ở trung tâm bàn cờ"**
- **"♟️ Nhập thành - Bảo vệ Vua và kích hoạt Xe"**

## 📋 Cấu trúc thư mục

```
chess-helper-extension/
├── manifest.json       # Cấu hình extension
├── content.js          # Logic chính phân tích và gợi ý
├── styles.css          # Giao diện UI
├── popup.html          # Popup khi nhấn vào icon extension
├── icon16.png          # Icon 16x16
├── icon48.png          # Icon 48x48
├── icon128.png         # Icon 128x128
└── README.md           # Hướng dẫn này
```

## ⚙️ Tùy chỉnh

Bạn có thể tùy chỉnh extension bằng cách chỉnh sửa:

- **styles.css**: Thay đổi màu sắc, kích thước panel
- **content.js**: Điều chỉnh logic gợi ý, thêm chiến thuật mới

## 🔧 Khắc phục sự cố

### Panel không hiển thị?
- Đảm bảo bạn đang ở trang chess.com/play hoặc chess.com/game
- Refresh lại trang
- Kiểm tra extension đã được bật trong chrome://extensions/

### Gợi ý không chính xác?
- Extension sử dụng logic cơ bản để phân tích
- Không thay thế engine cờ chuyên nghiệp
- Nên kết hợp với kiến thức cờ vua của bạn

### Panel bị che khuất?
- Kéo panel đến vị trí khác trên màn hình
- Điều chỉnh trong file styles.css (top, right properties)

## 📝 Lưu ý

- Extension này chỉ nhằm mục đích **học tập và luyện tập**
- Không nên sử dụng trong các trận đấu chính thức hoặc rated
- Gợi ý dựa trên logic cơ bản, không phải AI engine mạnh
- Hãy tôn trọng fair play khi chơi cờ

## 🚀 Phát triển trong tương lai

- [ ] Tích hợp Stockfish engine để gợi ý chính xác hơn
- [ ] Phân tích sâu hơn về chiến thuật và khai cuộc
- [ ] Thêm chế độ training với giải thích chi tiết
- [ ] Hỗ trợ nhiều biến thể cờ vua
- [ ] Tùy chỉnh độ mạnh của gợi ý

## 📄 License

MIT License - Tự do sử dụng và chỉnh sửa

## 🤝 Đóng góp

Mọi đóng góp đều được chào đón! Hãy tạo pull request hoặc báo cáo bug.

---

**Chúc bạn chơi cờ vui vẻ! ♟️**
