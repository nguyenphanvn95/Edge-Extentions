// Chess.com Move Helper - Content Script (Improved Version)

class ChessMoveHelper {
  constructor() {
    this.enabled = false;
    this.board = null;
    this.suggestionsPanel = null;
    this.currentPosition = null;
    this.moveCount = 0;
    this.init();
  }

  init() {
    console.log('♟️ Chess Move Helper v2.0 initialized');
    this.createUI();
    this.waitForBoard();
  }

  createUI() {
    // Tạo panel gợi ý
    this.suggestionsPanel = document.createElement('div');
    this.suggestionsPanel.id = 'chess-helper-panel';
    this.suggestionsPanel.innerHTML = `
      <div class="chess-helper-header">
        <h3>🤖 Trợ Lý Cờ Vua</h3>
        <button id="toggle-helper" class="helper-toggle">Bật</button>
      </div>
      <div class="chess-helper-content">
        <div id="suggestions-list">
          <p class="helper-hint">Nhấn "Bật" để nhận gợi ý nước đi</p>
        </div>
        <div class="helper-status" id="helper-status"></div>
      </div>
    `;

    // Thêm vào trang
    document.body.appendChild(this.suggestionsPanel);

    // Xử lý sự kiện toggle
    const toggleBtn = document.getElementById('toggle-helper');
    toggleBtn.addEventListener('click', () => this.toggleHelper());
  }

  toggleHelper() {
    this.enabled = !this.enabled;
    const toggleBtn = document.getElementById('toggle-helper');
    toggleBtn.textContent = this.enabled ? 'Tắt' : 'Bật';
    toggleBtn.classList.toggle('active', this.enabled);

    if (this.enabled) {
      this.showStatus('🔍 Đang phân tích bàn cờ...');
      setTimeout(() => this.analyzePosition(), 500);
    } else {
      this.clearSuggestions();
      this.showStatus('');
    }
  }

  waitForBoard() {
    let attempts = 0;
    const maxAttempts = 20;
    
    const checkBoard = setInterval(() => {
      attempts++;
      
      // Thử nhiều cách tìm bàn cờ
      const selectors = [
        'chess-board',
        '.board',
        '[class*="board-"]',
        '#board-layout-main',
        '[id*="board"]'
      ];
      
      let boardFound = false;
      
      for (const selector of selectors) {
        const board = document.querySelector(selector);
        if (board) {
          console.log(`✅ Found board with selector: ${selector}`);
          this.board = board;
          boardFound = true;
          this.observeBoardChanges();
          clearInterval(checkBoard);
          this.showStatus('✅ Đã kết nối với bàn cờ');
          break;
        }
      }
      
      if (!boardFound && attempts >= maxAttempts) {
        console.log('❌ Could not find chess board after', maxAttempts, 'attempts');
        clearInterval(checkBoard);
        this.showStatus('⚠️ Không tìm thấy bàn cờ. Hãy refresh trang.');
      }
    }, 500);
  }

  observeBoardChanges() {
    if (!this.board) return;
    
    const observer = new MutationObserver((mutations) => {
      if (this.enabled) {
        this.moveCount++;
        setTimeout(() => this.analyzePosition(), 300);
      }
    });

    observer.observe(this.board, {
      childList: true,
      subtree: true,
      attributes: true,
      characterData: true
    });
    
    console.log('👀 Observing board changes');
  }

  analyzePosition() {
    try {
      console.log('🔍 Starting position analysis...');
      const position = this.getBoardPosition();
      
      if (!position || position.pieces.length === 0) {
        this.showMessage('⏳ Đang chờ bàn cờ sẵn sàng...');
        this.showStatus(`🔍 Tìm thấy ${position ? position.pieces.length : 0} quân`);
        return;
      }

      console.log(`✅ Found ${position.pieces.length} pieces`);
      this.showStatus(`♟️ Phân tích ${position.pieces.length} quân cờ`);
      
      const suggestions = this.generateSuggestions(position);
      this.displaySuggestions(suggestions);
      
    } catch (error) {
      console.error('❌ Analysis error:', error);
      this.showMessage('❌ Lỗi: ' + error.message);
      this.showStatus('❌ Có lỗi xảy ra');
    }
  }

  getBoardPosition() {
    console.log('🔎 Detecting pieces...');
    
    // Thử nhiều cách tìm quân cờ
    const pieceSelectors = [
      '.piece',
      '[class*="piece"]',
      '[class^="piece-"]',
      'piece',
      '.chess-piece'
    ];
    
    let allPieces = [];
    
    for (const selector of pieceSelectors) {
      const pieces = document.querySelectorAll(selector);
      if (pieces.length > 0) {
        console.log(`Found ${pieces.length} pieces with: ${selector}`);
        allPieces = Array.from(pieces);
        break;
      }
    }
    
    // Thử trong shadow DOM nếu có
    if (allPieces.length === 0) {
      const chessBoard = document.querySelector('chess-board');
      if (chessBoard?.shadowRoot) {
        const shadowPieces = chessBoard.shadowRoot.querySelectorAll('.piece, [class*="piece"]');
        if (shadowPieces.length > 0) {
          console.log(`Found ${shadowPieces.length} pieces in shadow DOM`);
          allPieces = Array.from(shadowPieces);
        }
      }
    }
    
    if (allPieces.length === 0) {
      console.log('⚠️ No pieces found');
      return { pieces: [], turn: true, isPlayerWhite: true };
    }

    const position = {
      pieces: [],
      turn: this.getPlayerTurn(),
      isPlayerWhite: this.isPlayerWhite()
    };

    allPieces.forEach((piece, index) => {
      const classes = piece.className || '';
      const pieceData = this.parsePieceInfo(piece, classes);
      
      if (pieceData) {
        position.pieces.push(pieceData);
      }
    });

    console.log(`📊 Parsed ${position.pieces.length} valid pieces`);
    return position;
  }

  parsePieceInfo(element, classes) {
    // Lấy loại quân
    const pieceType = this.getPieceTypeFromClasses(classes) || this.getPieceTypeFromElement(element);
    
    // Lấy màu
    let color = null;
    if (classes.includes('w') || classes.includes('white')) color = 'white';
    else if (classes.includes('b') || classes.includes('black')) color = 'black';
    
    // Thử lấy từ data attributes
    if (!color) {
      const colorAttr = element.getAttribute('data-color') || element.getAttribute('color');
      if (colorAttr) color = colorAttr;
    }
    
    // Lấy vị trí ô
    const square = this.getSquareFromClasses(classes) || 
                   this.getSquareFromElement(element) ||
                   this.getSquareFromPosition(element);
    
    if (pieceType && color && square) {
      return { type: pieceType, color: color, square: square };
    }
    
    return null;
  }

  getPieceTypeFromElement(element) {
    // Thử từ data attributes
    const typeAttr = element.getAttribute('data-piece') || 
                     element.getAttribute('piece') ||
                     element.getAttribute('data-type');
    if (typeAttr) {
      const type = typeAttr.toLowerCase();
      if (type.includes('pawn')) return 'pawn';
      if (type.includes('knight')) return 'knight';
      if (type.includes('bishop')) return 'bishop';
      if (type.includes('rook')) return 'rook';
      if (type.includes('queen')) return 'queen';
      if (type.includes('king')) return 'king';
    }
    return null;
  }

  getSquareFromPosition(element) {
    // Thử lấy từ transform CSS
    const style = window.getComputedStyle(element);
    const transform = style.transform;
    
    if (transform && transform !== 'none') {
      const match = transform.match(/translate\(([^,]+),\s*([^)]+)\)/);
      if (match) {
        // Parse pixel values to square
        const x = parseFloat(match[1]);
        const y = parseFloat(match[2]);
        
        // Giả sử mỗi ô có kích thước ~ 12.5% của bàn cờ
        const fileIndex = Math.floor(x / (window.innerWidth * 0.125));
        const rankIndex = Math.floor(y / (window.innerHeight * 0.125));
        
        if (fileIndex >= 0 && fileIndex < 8 && rankIndex >= 0 && rankIndex < 8) {
          const file = String.fromCharCode(97 + fileIndex);
          const rank = 8 - rankIndex;
          return file + rank;
        }
      }
    }
    
    return null;
  }

  getSquareFromClasses(classes) {
    const match = classes.match(/square-(\d+)/);
    if (match) {
      const num = parseInt(match[1]);
      const file = String.fromCharCode(97 + (num % 10 - 1));
      const rank = Math.floor(num / 10);
      if (file >= 'a' && file <= 'h' && rank >= 1 && rank <= 8) {
        return file + rank;
      }
    }
    return null;
  }

  getSquareFromElement(element) {
    // Thử từ data attributes
    const square = element.getAttribute('data-square') || 
                   element.getAttribute('square');
    if (square && /^[a-h][1-8]$/.test(square)) {
      return square;
    }
    return null;
  }

  getPieceTypeFromClasses(classes) {
    if (!classes) return null;
    
    const lower = classes.toLowerCase();
    if (lower.includes('wp') || lower.includes('bp') || lower.includes('pawn')) return 'pawn';
    if (lower.includes('wn') || lower.includes('bn') || lower.includes('knight')) return 'knight';
    if (lower.includes('wb') || lower.includes('bb') || lower.includes('bishop')) return 'bishop';
    if (lower.includes('wr') || lower.includes('br') || lower.includes('rook')) return 'rook';
    if (lower.includes('wq') || lower.includes('bq') || lower.includes('queen')) return 'queen';
    if (lower.includes('wk') || lower.includes('bk') || lower.includes('king')) return 'king';
    
    return null;
  }

  getPlayerTurn() {
    // Kiểm tra lượt đi - thử nhiều cách
    const indicators = [
      '.clock-player-turn',
      '[class*="clock"][class*="active"]',
      '.player-turn',
      '[class*="turn"]'
    ];
    
    for (const selector of indicators) {
      if (document.querySelector(selector)) {
        return true;
      }
    }
    
    return true; // Mặc định là lượt người chơi
  }

  isPlayerWhite() {
    // Xác định màu quân của người chơi
    const board = this.board;
    if (!board) return true;
    
    const classes = board.className || '';
    return !classes.includes('flipped');
  }

  generateSuggestions(position) {
    const suggestions = [];
    const playerColor = position.isPlayerWhite ? 'white' : 'black';
    
    console.log(`🎯 Generating suggestions for ${playerColor}`);

    // Nếu không có quân cờ nào
    if (position.pieces.length === 0) {
      return [{
        move: 'Chưa phát hiện quân cờ',
        reason: 'Hãy bắt đầu một ván cờ mới',
        priority: 0
      }];
    }

    const playerPieces = position.pieces.filter(p => p.color === playerColor);
    const opponentPieces = position.pieces.filter(p => p.color !== playerColor);
    
    console.log(`👤 Player has ${playerPieces.length} pieces`);
    console.log(`🤖 Opponent has ${opponentPieces.length} pieces`);

    // 1. Gợi ý chung về vị trí
    suggestions.push({
      move: `Bạn có ${playerPieces.length} quân`,
      reason: `Đối thủ có ${opponentPieces.length} quân`,
      priority: 0
    });

    // 2. Phân tích quân cờ quan trọng
    const playerQueen = playerPieces.find(p => p.type === 'queen');
    const opponentQueen = opponentPieces.find(p => p.type === 'queen');
    
    if (opponentQueen) {
      suggestions.push({
        move: `Hậu đối thủ ở ${opponentQueen.square}`,
        reason: '🎯 Tìm cách tấn công hoặc kiềm chế',
        priority: 2
      });
    }
    
    if (playerQueen) {
      suggestions.push({
        move: `Hậu của bạn ở ${playerQueen.square}`,
        reason: '♛ Hãy bảo vệ và sử dụng Hậu hiệu quả',
        priority: 1
      });
    }

    // 3. Đếm số quân theo loại
    const playerKnights = playerPieces.filter(p => p.type === 'knight');
    const playerBishops = playerPieces.filter(p => p.type === 'bishop');
    const playerRooks = playerPieces.filter(p => p.type === 'rook');
    
    if (playerKnights.length > 0) {
      suggestions.push({
        move: 'Phát triển Mã',
        reason: `♞ Bạn có ${playerKnights.length} Mã - hãy đặt chúng ở vị trí tốt`,
        priority: 1
      });
    }
    
    if (playerBishops.length > 0) {
      suggestions.push({
        move: 'Kích hoạt Tượng',
        reason: `♝ Bạn có ${playerBishops.length} Tượng - hãy mở đường chéo`,
        priority: 1
      });
    }
    
    if (playerRooks.length > 0) {
      suggestions.push({
        move: 'Sử dụng Xe',
        reason: `♜ Bạn có ${playerRooks.length} Xe - kiểm soát hàng ngang/dọc`,
        priority: 1
      });
    }

    // 4. Gợi ý chiến thuật chung
    suggestions.push({
      move: 'Kiểm soát trung tâm',
      reason: '♟️ Các ô d4, d5, e4, e5 rất quan trọng',
      priority: 1
    });
    
    suggestions.push({
      move: 'Bảo vệ Vua',
      reason: '♚ Nhập thành sớm để bảo vệ Vua',
      priority: 2
    });

    // Sắp xếp theo độ ưu tiên
    suggestions.sort((a, b) => b.priority - a.priority);

    return suggestions.slice(0, 6);
  }

  displaySuggestions(suggestions) {
    const container = document.getElementById('suggestions-list');
    
    if (suggestions.length === 0) {
      container.innerHTML = '<p class="helper-hint">Không có gợi ý lúc này</p>';
      return;
    }

    let html = '<div class="suggestions">';
    suggestions.forEach((suggestion, index) => {
      html += `
        <div class="suggestion-item priority-${suggestion.priority}">
          <div class="suggestion-number">${index + 1}</div>
          <div class="suggestion-details">
            <div class="suggestion-move">${suggestion.move}</div>
            <div class="suggestion-reason">${suggestion.reason}</div>
          </div>
        </div>
      `;
    });
    html += '</div>';

    container.innerHTML = html;
  }

  showMessage(message) {
    const container = document.getElementById('suggestions-list');
    container.innerHTML = `<p class="helper-hint">${message}</p>`;
  }

  showStatus(status) {
    const statusEl = document.getElementById('helper-status');
    if (statusEl) {
      statusEl.textContent = status;
      statusEl.style.display = status ? 'block' : 'none';
    }
  }

  clearSuggestions() {
    const container = document.getElementById('suggestions-list');
    container.innerHTML = '<p class="helper-hint">Trợ lý đã tắt</p>';
  }
}

// Khởi tạo khi trang được tải
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 Initializing Chess Helper on DOMContentLoaded');
    new ChessMoveHelper();
  });
} else {
  console.log('🚀 Initializing Chess Helper immediately');
  new ChessMoveHelper();
}
