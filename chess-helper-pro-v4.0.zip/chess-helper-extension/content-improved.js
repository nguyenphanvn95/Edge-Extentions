// Chess.com Move Helper - Enhanced Version with Auto-Update and Smart Suggestions

class ChessMoveHelper {
  constructor() {
    this.enabled = false;
    this.board = null;
    this.suggestionsPanel = null;
    this.currentPosition = null;
    this.lastMoveCount = 0;
    this.engine = new ChessEngine();
    this.highlightedSquares = [];
    this.autoUpdateEnabled = true;
    this.updateInterval = null;
    this.init();
  }

  init() {
    console.log('♟️ Chess Move Helper v3.0 - Enhanced Edition');
    this.createUI();
    this.waitForBoard();
  }

  createUI() {
    // Tạo panel gợi ý với giao diện nâng cấp
    this.suggestionsPanel = document.createElement('div');
    this.suggestionsPanel.id = 'chess-helper-panel';
    this.suggestionsPanel.innerHTML = `
      <div class="chess-helper-header">
        <h3>🤖 Trợ Lý Cờ Vua Pro</h3>
        <div class="header-controls">
          <button id="toggle-helper" class="helper-toggle">Bật</button>
          <button id="toggle-auto" class="helper-auto active" title="Tự động cập nhật">🔄</button>
        </div>
      </div>
      <div class="chess-helper-content">
        <div class="position-eval" id="position-eval">
          <div class="eval-bar">
            <div class="eval-fill" id="eval-fill"></div>
          </div>
          <div class="eval-score" id="eval-score">+0.0</div>
        </div>
        <div id="suggestions-list">
          <p class="helper-hint">Nhấn "Bật" để nhận gợi ý nước đi thông minh</p>
        </div>
        <div class="helper-status" id="helper-status"></div>
      </div>
    `;

    document.body.appendChild(this.suggestionsPanel);

    // Xử lý sự kiện
    document.getElementById('toggle-helper').addEventListener('click', () => this.toggleHelper());
    document.getElementById('toggle-auto').addEventListener('click', () => this.toggleAutoUpdate());
  }

  toggleHelper() {
    this.enabled = !this.enabled;
    const toggleBtn = document.getElementById('toggle-helper');
    toggleBtn.textContent = this.enabled ? 'Tắt' : 'Bật';
    toggleBtn.classList.toggle('active', this.enabled);

    if (this.enabled) {
      this.showStatus('🔍 Đang phân tích bàn cờ...');
      setTimeout(() => this.analyzePosition(), 500);
      
      // Bắt đầu auto-update nếu được bật
      if (this.autoUpdateEnabled) {
        this.startAutoUpdate();
      }
    } else {
      this.clearSuggestions();
      this.clearHighlights();
      this.showStatus('');
      this.stopAutoUpdate();
    }
  }

  toggleAutoUpdate() {
    this.autoUpdateEnabled = !this.autoUpdateEnabled;
    const autoBtn = document.getElementById('toggle-auto');
    autoBtn.classList.toggle('active', this.autoUpdateEnabled);
    autoBtn.title = this.autoUpdateEnabled ? 'Tự động cập nhật: BẬT' : 'Tự động cập nhật: TẮT';

    if (this.enabled) {
      if (this.autoUpdateEnabled) {
        this.startAutoUpdate();
        this.showStatus('✅ Tự động cập nhật: BẬT');
      } else {
        this.stopAutoUpdate();
        this.showStatus('⏸️ Tự động cập nhật: TẮT');
      }
    }
  }

  startAutoUpdate() {
    this.stopAutoUpdate(); // Clear any existing interval
    
    // Check for updates every 1 second
    this.updateInterval = setInterval(() => {
      if (this.enabled) {
        this.checkForUpdates();
      }
    }, 1000);
    
    console.log('🔄 Auto-update started');
  }

  stopAutoUpdate() {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
      this.updateInterval = null;
      console.log('⏸️ Auto-update stopped');
    }
  }

  checkForUpdates() {
    const position = this.getBoardPosition();
    
    if (!position || position.pieces.length === 0) {
      return;
    }

    // Kiểm tra xem có thay đổi không
    const currentHash = this.getPositionHash(position);
    const lastHash = this.currentPosition ? this.getPositionHash(this.currentPosition) : null;

    if (currentHash !== lastHash) {
      console.log('🔔 Position changed detected!');
      this.analyzePosition();
    }
  }

  getPositionHash(position) {
    // Tạo hash đơn giản từ vị trí các quân
    return position.pieces
      .map(p => `${p.type}${p.color}${p.square}`)
      .sort()
      .join('|');
  }

  waitForBoard() {
    let attempts = 0;
    const maxAttempts = 30;
    
    const checkBoard = setInterval(() => {
      attempts++;
      
      const selectors = [
        'chess-board',
        '.board',
        '[class*="board-"]',
        '#board-layout-main',
        '[id*="board"]',
        '.game-board'
      ];
      
      let boardFound = false;
      
      for (const selector of selectors) {
        const board = document.querySelector(selector);
        if (board) {
          console.log(`✅ Found board with: ${selector}`);
          this.board = board;
          boardFound = true;
          this.observeBoardChanges();
          clearInterval(checkBoard);
          this.showStatus('✅ Đã kết nối với bàn cờ');
          break;
        }
      }
      
      if (!boardFound && attempts >= maxAttempts) {
        console.log('❌ Board not found after', maxAttempts, 'attempts');
        clearInterval(checkBoard);
        this.showStatus('⚠️ Không tìm thấy bàn cờ. Vui lòng refresh trang.');
      }
    }, 500);
  }

  observeBoardChanges() {
    if (!this.board) return;
    
    const observer = new MutationObserver((mutations) => {
      if (this.enabled && !this.autoUpdateEnabled) {
        // Chỉ cập nhật qua observer nếu auto-update tắt
        this.lastMoveCount++;
        console.log('📝 Move detected via observer');
        setTimeout(() => this.analyzePosition(), 300);
      }
    });

    observer.observe(this.board, {
      childList: true,
      subtree: true,
      attributes: true,
      characterData: true
    });
    
    console.log('👀 Board observer active');
  }

  analyzePosition() {
    try {
      console.log('🔍 Analyzing position...');
      const position = this.getBoardPosition();
      
      if (!position || position.pieces.length === 0) {
        this.showMessage('⏳ Đang chờ bàn cờ...');
        return;
      }

      console.log(`✅ Found ${position.pieces.length} pieces`);
      this.currentPosition = position;
      
      // Đánh giá vị trí
      const evaluation = this.engine.evaluatePosition(position, position.isPlayerWhite ? 'white' : 'black');
      this.updateEvaluation(evaluation);
      
      // Tạo gợi ý nước đi
      const playerColor = position.isPlayerWhite ? 'white' : 'black';
      const suggestions = this.engine.getBestMoves(position, playerColor, 6);
      
      this.displaySuggestions(suggestions, position);
      
      this.showStatus(`♟️ Đã phân tích ${position.pieces.length} quân • Tìm thấy ${suggestions.length} nước đi`);
      
    } catch (error) {
      console.error('❌ Analysis error:', error);
      this.showMessage('❌ Lỗi phân tích: ' + error.message);
    }
  }

  updateEvaluation(score) {
    const scoreEl = document.getElementById('eval-score');
    const fillEl = document.getElementById('eval-fill');
    
    if (!scoreEl || !fillEl) return;

    // Chuyển đổi score thành centipawns
    const displayScore = (score / 100).toFixed(1);
    scoreEl.textContent = score >= 0 ? `+${displayScore}` : displayScore;
    
    // Cập nhật thanh đánh giá (0-100%)
    const percentage = Math.max(0, Math.min(100, 50 + (score / 50)));
    fillEl.style.width = percentage + '%';
    
    // Màu sắc dựa trên điểm
    if (score > 200) {
      fillEl.style.backgroundColor = '#4caf50'; // Xanh lá - thắng thế
      scoreEl.style.color = '#4caf50';
    } else if (score < -200) {
      fillEl.style.backgroundColor = '#f44336'; // Đỏ - thua thế
      scoreEl.style.color = '#f44336';
    } else {
      fillEl.style.backgroundColor = '#ffc107'; // Vàng - cân bằng
      scoreEl.style.color = '#ffc107';
    }
  }

  getBoardPosition() {
    console.log('🔎 Detecting pieces...');
    
    const pieceSelectors = [
      '.piece',
      '[class*="piece"]',
      '[class^="piece-"]',
      'piece',
      '.chess-piece'
    ];
    
    let allPieces = [];
    
    for (const selector of pieceSelectors) {
      const pieces = document.querySelectorAll(selector);
      if (pieces.length > 0) {
        console.log(`Found ${pieces.length} pieces with: ${selector}`);
        allPieces = Array.from(pieces);
        break;
      }
    }
    
    // Shadow DOM check
    if (allPieces.length === 0) {
      const chessBoard = document.querySelector('chess-board');
      if (chessBoard?.shadowRoot) {
        const shadowPieces = chessBoard.shadowRoot.querySelectorAll('.piece, [class*="piece"]');
        if (shadowPieces.length > 0) {
          console.log(`Found ${shadowPieces.length} pieces in shadow DOM`);
          allPieces = Array.from(shadowPieces);
        }
      }
    }
    
    if (allPieces.length === 0) {
      return { pieces: [], turn: true, isPlayerWhite: true };
    }

    const position = {
      pieces: [],
      turn: this.getPlayerTurn(),
      isPlayerWhite: this.isPlayerWhite()
    };

    allPieces.forEach(piece => {
      const classes = piece.className || '';
      const pieceData = this.parsePieceInfo(piece, classes);
      
      if (pieceData) {
        position.pieces.push(pieceData);
      }
    });

    console.log(`📊 Parsed ${position.pieces.length} pieces`);
    return position;
  }

  parsePieceInfo(element, classes) {
    const pieceType = this.getPieceTypeFromClasses(classes) || this.getPieceTypeFromElement(element);
    
    let color = null;
    if (classes.includes('w') || classes.includes('white')) color = 'white';
    else if (classes.includes('b') || classes.includes('black')) color = 'black';
    
    if (!color) {
      const colorAttr = element.getAttribute('data-color') || element.getAttribute('color');
      if (colorAttr) color = colorAttr;
    }
    
    const square = this.getSquareFromClasses(classes) || 
                   this.getSquareFromElement(element) ||
                   this.getSquareFromPosition(element);
    
    if (pieceType && color && square) {
      return { type: pieceType, color: color, square: square };
    }
    
    return null;
  }

  getPieceTypeFromElement(element) {
    const typeAttr = element.getAttribute('data-piece') || 
                     element.getAttribute('piece') ||
                     element.getAttribute('data-type');
    if (typeAttr) {
      const type = typeAttr.toLowerCase();
      if (type.includes('pawn')) return 'pawn';
      if (type.includes('knight')) return 'knight';
      if (type.includes('bishop')) return 'bishop';
      if (type.includes('rook')) return 'rook';
      if (type.includes('queen')) return 'queen';
      if (type.includes('king')) return 'king';
    }
    return null;
  }

  getSquareFromPosition(element) {
    const style = window.getComputedStyle(element);
    const transform = style.transform;
    
    if (transform && transform !== 'none') {
      const match = transform.match(/translate\(([^,]+),\s*([^)]+)\)/);
      if (match) {
        const x = parseFloat(match[1]);
        const y = parseFloat(match[2]);
        
        const fileIndex = Math.floor(x / (window.innerWidth * 0.125));
        const rankIndex = Math.floor(y / (window.innerHeight * 0.125));
        
        if (fileIndex >= 0 && fileIndex < 8 && rankIndex >= 0 && rankIndex < 8) {
          const file = String.fromCharCode(97 + fileIndex);
          const rank = 8 - rankIndex;
          return file + rank;
        }
      }
    }
    
    return null;
  }

  getSquareFromClasses(classes) {
    const match = classes.match(/square-(\d+)/);
    if (match) {
      const num = parseInt(match[1]);
      const file = String.fromCharCode(97 + (num % 10 - 1));
      const rank = Math.floor(num / 10);
      if (file >= 'a' && file <= 'h' && rank >= 1 && rank <= 8) {
        return file + rank;
      }
    }
    return null;
  }

  getSquareFromElement(element) {
    const square = element.getAttribute('data-square') || 
                   element.getAttribute('square');
    if (square && /^[a-h][1-8]$/.test(square)) {
      return square;
    }
    return null;
  }

  getPieceTypeFromClasses(classes) {
    if (!classes) return null;
    
    const lower = classes.toLowerCase();
    if (lower.includes('wp') || lower.includes('bp') || lower.includes('pawn')) return 'pawn';
    if (lower.includes('wn') || lower.includes('bn') || lower.includes('knight')) return 'knight';
    if (lower.includes('wb') || lower.includes('bb') || lower.includes('bishop')) return 'bishop';
    if (lower.includes('wr') || lower.includes('br') || lower.includes('rook')) return 'rook';
    if (lower.includes('wq') || lower.includes('bq') || lower.includes('queen')) return 'queen';
    if (lower.includes('wk') || lower.includes('bk') || lower.includes('king')) return 'king';
    
    return null;
  }

  getPlayerTurn() {
    const indicators = [
      '.clock-player-turn',
      '[class*="clock"][class*="active"]',
      '.player-turn',
      '[class*="turn"]'
    ];
    
    for (const selector of indicators) {
      if (document.querySelector(selector)) {
        return true;
      }
    }
    
    return true;
  }

  isPlayerWhite() {
    const board = this.board;
    if (!board) return true;
    
    const classes = board.className || '';
    return !classes.includes('flipped');
  }

  displaySuggestions(suggestions, position) {
    const container = document.getElementById('suggestions-list');
    
    if (suggestions.length === 0) {
      container.innerHTML = '<p class="helper-hint">Không tìm thấy nước đi hợp lệ</p>';
      return;
    }

    let html = '<div class="suggestions">';
    suggestions.forEach((move, index) => {
      const description = this.engine.getMoveDescription(move);
      const reason = this.engine.getMoveReason(move);
      const scoreDisplay = move.score > 0 ? `+${move.score}` : move.score;
      
      // Icon dựa trên loại nước đi
      let icon = '♟️';
      if (move.type === 'capture') icon = '⚔️';
      else if (move.score > 100) icon = '⭐';
      else if (move.score > 50) icon = '✨';
      
      html += `
        <div class="suggestion-item" data-from="${move.from}" data-to="${move.to}" onclick="window.chessMoveHelper.highlightMove('${move.from}', '${move.to}')">
          <div class="suggestion-number">${index + 1}</div>
          <div class="suggestion-details">
            <div class="suggestion-move">
              ${icon} ${description}
              <span class="move-score">${scoreDisplay}</span>
            </div>
            <div class="suggestion-reason">${reason}</div>
          </div>
        </div>
      `;
    });
    html += '</div>';

    container.innerHTML = html;
  }

  highlightMove(fromSquare, toSquare) {
    console.log(`🎯 Highlighting move: ${fromSquare} → ${toSquare}`);
    
    this.clearHighlights();
    
    // Tìm và highlight các ô
    const fromEl = this.findSquareElement(fromSquare);
    const toEl = this.findSquareElement(toSquare);
    
    if (fromEl) {
      fromEl.classList.add('chess-helper-highlight-from');
      this.highlightedSquares.push(fromEl);
    }
    
    if (toEl) {
      toEl.classList.add('chess-helper-highlight-to');
      this.highlightedSquares.push(toEl);
    }
    
    // Tự động xóa highlight sau 3 giây
    setTimeout(() => this.clearHighlights(), 3000);
  }

  findSquareElement(square) {
    // Thử tìm element của ô cờ
    const selectors = [
      `[data-square="${square}"]`,
      `.square-${square}`,
      `[square="${square}"]`
    ];
    
    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el) return el;
    }
    
    // Thử trong shadow DOM
    const chessBoard = document.querySelector('chess-board');
    if (chessBoard?.shadowRoot) {
      for (const selector of selectors) {
        const el = chessBoard.shadowRoot.querySelector(selector);
        if (el) return el;
      }
    }
    
    return null;
  }

  clearHighlights() {
    this.highlightedSquares.forEach(el => {
      el.classList.remove('chess-helper-highlight-from');
      el.classList.remove('chess-helper-highlight-to');
    });
    this.highlightedSquares = [];
  }

  showMessage(message) {
    const container = document.getElementById('suggestions-list');
    container.innerHTML = `<p class="helper-hint">${message}</p>`;
  }

  showStatus(status) {
    const statusEl = document.getElementById('helper-status');
    if (statusEl) {
      statusEl.textContent = status;
      statusEl.style.display = status ? 'block' : 'none';
    }
  }

  clearSuggestions() {
    const container = document.getElementById('suggestions-list');
    container.innerHTML = '<p class="helper-hint">Trợ lý đã tắt</p>';
  }
}

// Make instance globally accessible for onclick handlers
window.chessMoveHelper = null;

// Initialize
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 Initializing Enhanced Chess Helper');
    window.chessMoveHelper = new ChessMoveHelper();
  });
} else {
  console.log('🚀 Initializing Enhanced Chess Helper');
  window.chessMoveHelper = new ChessMoveHelper();
}
