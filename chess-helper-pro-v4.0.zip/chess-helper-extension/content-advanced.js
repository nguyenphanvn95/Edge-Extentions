// Chess.com Move Helper - Advanced Multi-Move Analysis

class ChessMoveHelper {
  constructor() {
    this.enabled = false;
    this.board = null;
    this.suggestionsPanel = null;
    this.currentPosition = null;
    this.lastMoveCount = 0;
    this.engine = new AdvancedChessEngine();
    this.highlightedSquares = [];
    this.autoUpdateEnabled = true;
    this.updateInterval = null;
    this.showSequences = true; // Toggle for sequence view
    this.init();
  }

  init() {
    console.log('♟️ Chess Move Helper v4.0 - Advanced Multi-Move Analysis');
    this.createUI();
    this.waitForBoard();
  }

  createUI() {
    this.suggestionsPanel = document.createElement('div');
    this.suggestionsPanel.id = 'chess-helper-panel';
    this.suggestionsPanel.innerHTML = `
      <div class="chess-helper-header">
        <h3>🤖 Trợ Lý Cờ Vua Pro</h3>
        <div class="header-controls">
          <button id="toggle-helper" class="helper-toggle">Bật</button>
          <button id="toggle-auto" class="helper-auto active" title="Tự động cập nhật">🔄</button>
          <button id="toggle-view" class="helper-view active" title="Xem chuỗi nước đi">🎯</button>
        </div>
      </div>
      <div class="chess-helper-content">
        <div class="position-eval" id="position-eval">
          <div class="eval-bar">
            <div class="eval-fill" id="eval-fill"></div>
          </div>
          <div class="eval-score" id="eval-score">+0.0</div>
        </div>
        <div class="view-tabs" id="view-tabs">
          <button class="tab-btn active" data-view="sequences">📊 Chiến Lược</button>
          <button class="tab-btn" data-view="moves">⚡ Nước Đi</button>
        </div>
        <div id="suggestions-list">
          <p class="helper-hint">Nhấn "Bật" để nhận phân tích chiến thuật</p>
        </div>
        <div class="helper-status" id="helper-status"></div>
      </div>
    `;

    document.body.appendChild(this.suggestionsPanel);

    document.getElementById('toggle-helper').addEventListener('click', () => this.toggleHelper());
    document.getElementById('toggle-auto').addEventListener('click', () => this.toggleAutoUpdate());
    document.getElementById('toggle-view').addEventListener('click', () => this.toggleView());
    
    // Tab switching
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        this.currentView = e.target.dataset.view;
        if (this.currentPosition) {
          this.analyzePosition();
        }
      });
    });
    
    this.currentView = 'sequences';
  }

  toggleHelper() {
    this.enabled = !this.enabled;
    const toggleBtn = document.getElementById('toggle-helper');
    toggleBtn.textContent = this.enabled ? 'Tắt' : 'Bật';
    toggleBtn.classList.toggle('active', this.enabled);

    if (this.enabled) {
      this.showStatus('🔍 Đang phân tích chiến thuật...');
      setTimeout(() => this.analyzePosition(), 500);
      
      if (this.autoUpdateEnabled) {
        this.startAutoUpdate();
      }
    } else {
      this.clearSuggestions();
      this.clearHighlights();
      this.showStatus('');
      this.stopAutoUpdate();
    }
  }

  toggleAutoUpdate() {
    this.autoUpdateEnabled = !this.autoUpdateEnabled;
    const autoBtn = document.getElementById('toggle-auto');
    autoBtn.classList.toggle('active', this.autoUpdateEnabled);
    autoBtn.title = this.autoUpdateEnabled ? 'Tự động cập nhật: BẬT' : 'Tự động cập nhật: TẮT';

    if (this.enabled) {
      if (this.autoUpdateEnabled) {
        this.startAutoUpdate();
        this.showStatus('✅ Tự động cập nhật: BẬT');
      } else {
        this.stopAutoUpdate();
        this.showStatus('⏸️ Tự động cập nhật: TẮT');
      }
    }
  }

  toggleView() {
    this.showSequences = !this.showSequences;
    const viewBtn = document.getElementById('toggle-view');
    viewBtn.classList.toggle('active', this.showSequences);
    viewBtn.title = this.showSequences ? 'Đang xem: Chuỗi nước đi' : 'Đang xem: Nước đơn';
    
    if (this.currentPosition) {
      this.analyzePosition();
    }
  }

  startAutoUpdate() {
    this.stopAutoUpdate();
    this.updateInterval = setInterval(() => {
      if (this.enabled) {
        this.checkForUpdates();
      }
    }, 1000);
    console.log('🔄 Auto-update started');
  }

  stopAutoUpdate() {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
      this.updateInterval = null;
    }
  }

  checkForUpdates() {
    const position = this.getBoardPosition();
    if (!position || position.pieces.length === 0) return;

    const currentHash = this.getPositionHash(position);
    const lastHash = this.currentPosition ? this.getPositionHash(this.currentPosition) : null;

    if (currentHash !== lastHash) {
      console.log('🔔 Position changed!');
      this.analyzePosition();
    }
  }

  getPositionHash(position) {
    return position.pieces.map(p => `${p.type}${p.color}${p.square}`).sort().join('|');
  }

  waitForBoard() {
    let attempts = 0;
    const maxAttempts = 30;
    
    const checkBoard = setInterval(() => {
      attempts++;
      const selectors = ['chess-board', '.board', '[class*="board-"]'];
      
      for (const selector of selectors) {
        const board = document.querySelector(selector);
        if (board) {
          console.log(`✅ Found board: ${selector}`);
          this.board = board;
          this.observeBoardChanges();
          clearInterval(checkBoard);
          this.showStatus('✅ Kết nối bàn cờ');
          return;
        }
      }
      
      if (attempts >= maxAttempts) {
        clearInterval(checkBoard);
        this.showStatus('⚠️ Không tìm thấy bàn cờ');
      }
    }, 500);
  }

  observeBoardChanges() {
    if (!this.board) return;
    
    const observer = new MutationObserver(() => {
      if (this.enabled && !this.autoUpdateEnabled) {
        setTimeout(() => this.analyzePosition(), 300);
      }
    });

    observer.observe(this.board, {
      childList: true,
      subtree: true,
      attributes: true
    });
  }

  analyzePosition() {
    try {
      console.log('🔍 Analyzing position...');
      const position = this.getBoardPosition();
      
      if (!position || position.pieces.length === 0) {
        this.showMessage('⏳ Đang chờ bàn cờ...');
        return;
      }

      console.log(`✅ Found ${position.pieces.length} pieces`);
      this.currentPosition = position;
      
      const evaluation = this.engine.evaluatePosition(position, position.isPlayerWhite ? 'white' : 'black');
      this.updateEvaluation(evaluation);
      
      const playerColor = position.isPlayerWhite ? 'white' : 'black';
      
      if (this.currentView === 'sequences') {
        // Tính toán chuỗi nước đi
        this.showStatus('🧠 Đang tính toán chiến thuật...');
        const sequences = this.engine.calculateMoveSequence(position, playerColor, 2);
        this.displaySequences(sequences, playerColor);
        this.showStatus(`♟️ Phân tích ${position.pieces.length} quân • ${sequences.length} chiến lược`);
      } else {
        // Hiển thị nước đi đơn
        const suggestions = this.engine.getBestMoves(position, playerColor, 6);
        this.displaySuggestions(suggestions);
        this.showStatus(`♟️ Phân tích ${position.pieces.length} quân • ${suggestions.length} nước đi`);
      }
      
    } catch (error) {
      console.error('❌ Error:', error);
      this.showMessage('❌ Lỗi: ' + error.message);
    }
  }

  updateEvaluation(score) {
    const scoreEl = document.getElementById('eval-score');
    const fillEl = document.getElementById('eval-fill');
    if (!scoreEl || !fillEl) return;

    const displayScore = (score / 100).toFixed(1);
    scoreEl.textContent = score >= 0 ? `+${displayScore}` : displayScore;
    
    const percentage = Math.max(0, Math.min(100, 50 + (score / 50)));
    fillEl.style.width = percentage + '%';
    
    if (score > 200) {
      fillEl.style.backgroundColor = '#4caf50';
      scoreEl.style.color = '#4caf50';
    } else if (score < -200) {
      fillEl.style.backgroundColor = '#f44336';
      scoreEl.style.color = '#f44336';
    } else {
      fillEl.style.backgroundColor = '#ffc107';
      scoreEl.style.color = '#ffc107';
    }
  }

  getBoardPosition() {
    console.log('🔎 Detecting pieces...');
    
    let allPieces = [];
    const chessBoard = document.querySelector('chess-board');
    
    if (chessBoard?.shadowRoot) {
      const pieces = chessBoard.shadowRoot.querySelectorAll('.piece, [class*="piece"]');
      if (pieces.length > 0) {
        allPieces = Array.from(pieces);
      }
    }
    
    if (allPieces.length === 0) {
      const pieces = document.querySelectorAll('.piece, [class*="piece"]');
      if (pieces.length > 0) {
        allPieces = Array.from(pieces);
      }
    }
    
    if (allPieces.length === 0) {
      return { pieces: [], turn: true, isPlayerWhite: true };
    }

    const position = {
      pieces: [],
      turn: true,
      isPlayerWhite: this.isPlayerWhite()
    };

    allPieces.forEach(pieceEl => {
      const pieceData = this.parsePieceFromElement(pieceEl);
      if (pieceData) {
        position.pieces.push(pieceData);
      }
    });

    console.log(`📊 Parsed ${position.pieces.length} pieces`);
    return position;
  }

  parsePieceFromElement(element) {
    const classes = element.className || '';
    const classList = classes.split(' ');
    
    let square = null;
    let pieceType = null;
    let color = null;
    
    // Parse square
    for (const cls of classList) {
      const squareMatch = cls.match(/square-(\d)(\d)/);
      if (squareMatch) {
        const file = parseInt(squareMatch[1]) - 1;
        const rank = parseInt(squareMatch[2]);
        if (file >= 0 && file <= 7 && rank >= 1 && rank <= 8) {
          square = String.fromCharCode(97 + file) + rank;
          break;
        }
      }
    }
    
    // Parse piece type and color using regex
    const lowerClasses = classes.toLowerCase();
    const pieceMatch = lowerClasses.match(/\b([wb])([pnbrqk])\b/);
    
    if (pieceMatch) {
      color = pieceMatch[1] === 'w' ? 'white' : 'black';
      const typeCode = pieceMatch[2];
      
      const typeMap = {
        'p': 'pawn', 'n': 'knight', 'b': 'bishop',
        'r': 'rook', 'q': 'queen', 'k': 'king'
      };
      pieceType = typeMap[typeCode];
    }
    
    if (pieceType && color && square) {
      return { type: pieceType, color: color, square: square };
    }
    
    return null;
  }

  isPlayerWhite() {
    const board = this.board;
    if (!board) return true;
    return !board.className.includes('flipped');
  }

  displaySequences(sequences, playerColor) {
    const container = document.getElementById('suggestions-list');
    
    if (sequences.length === 0) {
      container.innerHTML = '<p class="helper-hint">Không tìm thấy chiến lược</p>';
      return;
    }

    let html = '<div class="sequences">';
    
    sequences.forEach((seq, index) => {
      const scoreDisplay = seq.finalScore > 0 ? `+${Math.round(seq.finalScore/100)*10}` : Math.round(seq.finalScore/100)*10;
      const sequenceDesc = this.engine.formatSequence(seq, playerColor);
      const scenarioDesc = this.engine.getScenarioSummary(seq.scenario);
      
      // Icon dựa trên score
      let icon = '📊';
      if (seq.finalScore > 300) icon = '🔥';
      else if (seq.finalScore > 100) icon = '⭐';
      else if (seq.finalScore > 0) icon = '✨';
      
      // Priority class
      let priorityClass = 'normal';
      if (seq.scenario.length > 0) {
        const topPriority = seq.scenario[0].priority;
        if (topPriority >= 5) priorityClass = 'high';
        else if (topPriority >= 4) priorityClass = 'medium';
      }
      
      html += `
        <div class="sequence-item priority-${priorityClass}" onclick="window.chessMoveHelper.highlightSequence(${index})">
          <div class="sequence-header">
            <div class="sequence-number">${index + 1}</div>
            <div class="sequence-score">${scoreDisplay}</div>
          </div>
          <div class="sequence-details">
            <div class="sequence-moves">${icon} ${sequenceDesc}</div>
            <div class="sequence-scenario">${scenarioDesc}</div>
            ${this.renderScenarioTags(seq.scenario)}
          </div>
        </div>
      `;
    });
    
    html += '</div>';
    container.innerHTML = html;
  }

  renderScenarioTags(scenarios) {
    if (scenarios.length === 0) return '';
    
    const tags = scenarios.slice(0, 3).map(s => {
      const emoji = s.description.split(' ')[0];
      const text = s.description.substring(emoji.length + 1);
      return `<span class="scenario-tag priority-${s.priority}">${emoji}</span>`;
    }).join('');
    
    return `<div class="scenario-tags">${tags}</div>`;
  }

  displaySuggestions(suggestions) {
    const container = document.getElementById('suggestions-list');
    
    if (suggestions.length === 0) {
      container.innerHTML = '<p class="helper-hint">Không có nước đi</p>';
      return;
    }

    let html = '<div class="suggestions">';
    suggestions.forEach((move, index) => {
      const description = this.engine.getMoveDescription(move);
      const reason = this.engine.getMoveReason(move);
      const scoreDisplay = move.score > 0 ? `+${move.score}` : move.score;
      
      let icon = '♟️';
      if (move.type === 'capture') icon = '⚔️';
      else if (move.score > 100) icon = '⭐';
      else if (move.score > 50) icon = '✨';
      
      html += `
        <div class="suggestion-item" onclick="window.chessMoveHelper.highlightMove('${move.from}', '${move.to}')">
          <div class="suggestion-number">${index + 1}</div>
          <div class="suggestion-details">
            <div class="suggestion-move">
              ${icon} ${description}
              <span class="move-score">${scoreDisplay}</span>
            </div>
            <div class="suggestion-reason">${reason}</div>
          </div>
        </div>
      `;
    });
    html += '</div>';
    container.innerHTML = html;
  }

  highlightSequence(index) {
    if (!this.currentPosition) return;
    
    const playerColor = this.currentPosition.isPlayerWhite ? 'white' : 'black';
    const sequences = this.engine.calculateMoveSequence(this.currentPosition, playerColor, 2);
    
    if (index >= sequences.length) return;
    
    const sequence = sequences[index];
    const firstMove = sequence.moves[0];
    
    if (firstMove) {
      this.highlightMove(firstMove.from, firstMove.to);
    }
  }

  highlightMove(fromSquare, toSquare) {
    console.log(`🎯 Highlight: ${fromSquare} → ${toSquare}`);
    this.clearHighlights();
    
    const fromEl = this.findSquareElement(fromSquare);
    const toEl = this.findSquareElement(toSquare);
    
    if (fromEl) {
      fromEl.classList.add('chess-helper-highlight-from');
      this.highlightedSquares.push(fromEl);
    }
    
    if (toEl) {
      toEl.classList.add('chess-helper-highlight-to');
      this.highlightedSquares.push(toEl);
    }
    
    setTimeout(() => this.clearHighlights(), 3000);
  }

  findSquareElement(square) {
    const selectors = [`[data-square="${square}"]`, `.square-${square}`];
    
    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el) return el;
    }
    
    const chessBoard = document.querySelector('chess-board');
    if (chessBoard?.shadowRoot) {
      for (const selector of selectors) {
        const el = chessBoard.shadowRoot.querySelector(selector);
        if (el) return el;
      }
    }
    
    return null;
  }

  clearHighlights() {
    this.highlightedSquares.forEach(el => {
      el.classList.remove('chess-helper-highlight-from');
      el.classList.remove('chess-helper-highlight-to');
    });
    this.highlightedSquares = [];
  }

  showMessage(message) {
    document.getElementById('suggestions-list').innerHTML = `<p class="helper-hint">${message}</p>`;
  }

  showStatus(status) {
    const statusEl = document.getElementById('helper-status');
    if (statusEl) {
      statusEl.textContent = status;
      statusEl.style.display = status ? 'block' : 'none';
    }
  }

  clearSuggestions() {
    document.getElementById('suggestions-list').innerHTML = '<p class="helper-hint">Trợ lý đã tắt</p>';
  }
}

window.chessMoveHelper = null;

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 Advanced Chess Helper v4.0');
    window.chessMoveHelper = new ChessMoveHelper();
  });
} else {
  console.log('🚀 Advanced Chess Helper v4.0');
  window.chessMoveHelper = new ChessMoveHelper();
}
