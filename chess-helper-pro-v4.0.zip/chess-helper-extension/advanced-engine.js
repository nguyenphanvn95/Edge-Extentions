// Advanced Chess Engine - Multi-move Analysis & Tactical Scenarios

class AdvancedChessEngine extends ChessEngine {
  constructor() {
    super();
    
    // Tactical patterns
    this.tacticalPatterns = {
      fork: 'Chĩa hai',
      pin: 'Ghim quân',
      skewer: 'Xiên que',
      discoveredAttack: 'Chiếu bí',
      doubleAttack: 'Tấn công kép',
      sacrifice: 'Đánh tráo',
      checkmate: 'Chiếu hết',
      check: 'Chiếu',
      defendedAttack: 'Tấn công có phòng thủ'
    };
  }

  // Tính toán chuỗi nước đi tốt nhất (2-3 bước)
  calculateMoveSequence(position, playerColor, depth = 2) {
    console.log(`🧠 Calculating ${depth}-move sequences for ${playerColor}...`);
    
    const sequences = [];
    const playerPieces = position.pieces.filter(p => p.color === playerColor);
    
    // Lấy các nước đi ban đầu tốt nhất
    const initialMoves = this.getBestMoves(position, playerColor, 8);
    
    initialMoves.forEach(firstMove => {
      // Tạo position sau nước đi đầu tiên
      const newPosition = this.makeMove(position, firstMove);
      if (!newPosition) return;
      
      // Tính phản ứng tốt nhất của đối thủ
      const opponentColor = playerColor === 'white' ? 'black' : 'white';
      const opponentMoves = this.getBestMoves(newPosition, opponentColor, 3);
      
      if (opponentMoves.length === 0) {
        // Không có phản ứng = có thể là chiếu hết hoặc rất tốt
        sequences.push({
          moves: [firstMove],
          finalScore: firstMove.score * 2,
          scenario: this.analyzeScenario(position, [firstMove]),
          depth: 1
        });
        return;
      }
      
      const opponentResponse = opponentMoves[0];
      
      // Position sau khi đối thủ đáp
      const position2 = this.makeMove(newPosition, opponentResponse);
      if (!position2) return;
      
      // Tính nước đi thứ 2 của người chơi
      const secondMoves = this.getBestMoves(position2, playerColor, 3);
      
      if (secondMoves.length > 0) {
        const secondMove = secondMoves[0];
        
        // Position sau nước thứ 2
        const position3 = this.makeMove(position2, secondMove);
        
        // Tính điểm cuối cùng
        const finalScore = position3 ? 
          this.evaluatePosition(position3, playerColor) : 
          secondMove.score;
        
        sequences.push({
          moves: [firstMove, opponentResponse, secondMove],
          finalScore: finalScore,
          scenario: this.analyzeScenario(position, [firstMove, opponentResponse, secondMove]),
          depth: 3
        });
      } else {
        // Chỉ có 2 nước
        sequences.push({
          moves: [firstMove, opponentResponse],
          finalScore: this.evaluatePosition(position2, playerColor),
          scenario: this.analyzeScenario(position, [firstMove, opponentResponse]),
          depth: 2
        });
      }
    });
    
    // Sắp xếp theo điểm
    sequences.sort((a, b) => b.finalScore - a.finalScore);
    
    console.log(`✅ Generated ${sequences.length} sequences`);
    return sequences.slice(0, 5);
  }

  // Tạo position mới sau một nước đi
  makeMove(position, move) {
    if (!move) return null;
    
    try {
      const newPieces = position.pieces.map(p => ({...p}));
      
      // Tìm quân cờ
      const pieceIndex = newPieces.findIndex(p => p.square === move.from);
      if (pieceIndex === -1) return null;
      
      // Di chuyển quân
      newPieces[pieceIndex].square = move.to;
      
      // Xóa quân bị ăn (nếu có)
      if (move.type === 'capture') {
        const capturedIndex = newPieces.findIndex(p => p.square === move.to && p !== newPieces[pieceIndex]);
        if (capturedIndex !== -1) {
          newPieces.splice(capturedIndex, 1);
        }
      }
      
      return {
        pieces: newPieces,
        turn: !position.turn,
        isPlayerWhite: position.isPlayerWhite
      };
    } catch (error) {
      console.error('Error making move:', error);
      return null;
    }
  }

  // Phân tích tình huống chiến thuật
  analyzeScenario(position, moveSequence) {
    const scenarios = [];
    
    if (moveSequence.length === 0) return scenarios;
    
    const firstMove = moveSequence[0];
    
    // Kiểm tra chiếu
    if (this.isCheck(position, firstMove)) {
      scenarios.push({
        type: 'check',
        description: '⚠️ Chiếu vua',
        priority: 5
      });
    }
    
    // Kiểm tra ăn quân có giá trị
    if (firstMove.type === 'capture') {
      const captureValue = this.pieceValues[firstMove.captured];
      const attackerValue = this.pieceValues[firstMove.piece];
      
      if (captureValue > attackerValue) {
        scenarios.push({
          type: 'favorableTrade',
          description: `💎 Đánh tráo có lợi (${firstMove.captured} > ${firstMove.piece})`,
          priority: 4
        });
      }
    }
    
    // Kiểm tra chĩa hai (fork)
    const fork = this.detectFork(position, firstMove);
    if (fork) {
      scenarios.push({
        type: 'fork',
        description: `🔱 Chĩa hai: Tấn công ${fork.targets} quân cùng lúc`,
        priority: 5
      });
    }
    
    // Kiểm tra ghim quân (pin)
    const pin = this.detectPin(position, firstMove);
    if (pin) {
      scenarios.push({
        type: 'pin',
        description: `📌 Ghim quân: ${pin.pinnedPiece} không thể di chuyển`,
        priority: 4
      });
    }
    
    // Kiểm tra tấn công kép
    const doubleAttack = this.detectDoubleAttack(position, firstMove);
    if (doubleAttack) {
      scenarios.push({
        type: 'doubleAttack',
        description: `⚔️ Tấn công kép: Đe dọa ${doubleAttack.count} quân`,
        priority: 4
      });
    }
    
    // Phân tích sequence dài hơn
    if (moveSequence.length >= 3) {
      const thirdMove = moveSequence[2];
      
      // Kiểm tra tactic combination
      if (thirdMove.type === 'capture') {
        scenarios.push({
          type: 'combination',
          description: '🎯 Chiến thuật phối hợp: Chuỗi tấn công hiệu quả',
          priority: 5
        });
      }
      
      // Kiểm tra cải thiện vị trí
      scenarios.push({
        type: 'positionalGain',
        description: '📈 Cải thiện vị trí: Tăng kiểm soát bàn cờ',
        priority: 3
      });
    }
    
    // Development bonus
    if (this.isDevelopmentMove(firstMove)) {
      scenarios.push({
        type: 'development',
        description: '♞ Phát triển quân: Ra khỏi hàng sau',
        priority: 2
      });
    }
    
    // Center control
    const centerSquares = ['d4', 'd5', 'e4', 'e5'];
    if (centerSquares.includes(firstMove.to)) {
      scenarios.push({
        type: 'centerControl',
        description: '🎯 Kiểm soát trung tâm',
        priority: 3
      });
    }
    
    return scenarios.sort((a, b) => b.priority - a.priority);
  }

  // Kiểm tra chiếu
  isCheck(position, move) {
    if (move.piece !== 'queen' && move.piece !== 'rook' && 
        move.piece !== 'bishop' && move.piece !== 'knight' && 
        move.piece !== 'pawn') {
      return false;
    }
    
    // Tìm vua đối phương
    const opponentColor = move.piece.includes('white') ? 'black' : 'white';
    const opponentKing = position.pieces.find(p => p.type === 'king' && p.color === opponentColor);
    
    if (!opponentKing) return false;
    
    // Tạo position giả định sau nước đi
    const newPosition = this.makeMove(position, move);
    if (!newPosition) return false;
    
    // Kiểm tra xem vua có bị tấn công không
    return this.isSquareAttacked(newPosition, opponentKing.square, move.color || opponentColor);
  }

  // Phát hiện chĩa hai (fork)
  detectFork(position, move) {
    const newPosition = this.makeMove(position, move);
    if (!newPosition) return null;
    
    const piece = newPosition.pieces.find(p => p.square === move.to);
    if (!piece) return null;
    
    const possibleMoves = this.getPieceMoves(newPosition, piece);
    const opponentColor = piece.color === 'white' ? 'black' : 'white';
    
    // Đếm số quân có giá trị cao bị tấn công
    const threatenedPieces = possibleMoves.filter(m => {
      if (m.type !== 'capture') return false;
      const capturedValue = this.pieceValues[m.captured];
      return capturedValue >= 300; // Knight value trở lên
    });
    
    if (threatenedPieces.length >= 2) {
      return {
        targets: threatenedPieces.length,
        pieces: threatenedPieces.map(m => m.captured)
      };
    }
    
    return null;
  }

  // Phát hiện ghim quân (pin)
  detectPin(position, move) {
    // Simplified pin detection
    if (move.piece !== 'bishop' && move.piece !== 'rook' && move.piece !== 'queen') {
      return null;
    }
    
    // Ghim quân phức tạp hơn, tạm thời return null
    return null;
  }

  // Phát hiện tấn công kép
  detectDoubleAttack(position, move) {
    const newPosition = this.makeMove(position, move);
    if (!newPosition) return null;
    
    const piece = newPosition.pieces.find(p => p.square === move.to);
    if (!piece) return null;
    
    const possibleMoves = this.getPieceMoves(newPosition, piece);
    const attacks = possibleMoves.filter(m => m.type === 'capture');
    
    if (attacks.length >= 2) {
      return {
        count: attacks.length,
        targets: attacks.map(m => m.captured)
      };
    }
    
    return null;
  }

  // Kiểm tra nước đi phát triển
  isDevelopmentMove(move) {
    const backRanks = ['1', '8'];
    const fromRank = move.from[1];
    const toRank = move.to[1];
    
    return backRanks.includes(fromRank) && !backRanks.includes(toRank);
  }

  // Format move sequence cho hiển thị
  formatSequence(sequence, playerColor) {
    const moves = sequence.moves;
    const opponentColor = playerColor === 'white' ? 'black' : 'white';
    
    let description = '';
    
    moves.forEach((move, index) => {
      const isPlayer = index % 2 === 0;
      const color = isPlayer ? playerColor : opponentColor;
      const moveDesc = this.getMoveDescription(move);
      
      if (index === 0) {
        description += `1️⃣ Bạn: ${moveDesc}`;
      } else if (index === 1) {
        description += ` → 2️⃣ Đối thủ: ${moveDesc}`;
      } else if (index === 2) {
        description += ` → 3️⃣ Bạn: ${moveDesc}`;
      }
    });
    
    return description;
  }

  // Lấy mô tả ngắn gọn của scenario
  getScenarioSummary(scenarios) {
    if (scenarios.length === 0) return 'Nước đi thông thường';
    
    const topScenarios = scenarios.slice(0, 2);
    return topScenarios.map(s => s.description).join(' • ');
  }
}
