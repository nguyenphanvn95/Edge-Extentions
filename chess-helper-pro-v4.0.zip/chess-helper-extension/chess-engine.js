// Chess Engine - Simple but Smart Move Generation and Evaluation

class ChessEngine {
  constructor() {
    this.pieceValues = {
      'pawn': 100,
      'knight': 320,
      'bishop': 330,
      'rook': 500,
      'queen': 900,
      'king': 20000
    };

    // Position bonuses for pieces (centipawns)
    this.positionBonus = {
      'pawn': [
        [0,  0,  0,  0,  0,  0,  0,  0],
        [50, 50, 50, 50, 50, 50, 50, 50],
        [10, 10, 20, 30, 30, 20, 10, 10],
        [5,  5, 10, 25, 25, 10,  5,  5],
        [0,  0,  0, 20, 20,  0,  0,  0],
        [5, -5,-10,  0,  0,-10, -5,  5],
        [5, 10, 10,-20,-20, 10, 10,  5],
        [0,  0,  0,  0,  0,  0,  0,  0]
      ],
      'knight': [
        [-50,-40,-30,-30,-30,-30,-40,-50],
        [-40,-20,  0,  0,  0,  0,-20,-40],
        [-30,  0, 10, 15, 15, 10,  0,-30],
        [-30,  5, 15, 20, 20, 15,  5,-30],
        [-30,  0, 15, 20, 20, 15,  0,-30],
        [-30,  5, 10, 15, 15, 10,  5,-30],
        [-40,-20,  0,  5,  5,  0,-20,-40],
        [-50,-40,-30,-30,-30,-30,-40,-50]
      ],
      'bishop': [
        [-20,-10,-10,-10,-10,-10,-10,-20],
        [-10,  0,  0,  0,  0,  0,  0,-10],
        [-10,  0,  5, 10, 10,  5,  0,-10],
        [-10,  5,  5, 10, 10,  5,  5,-10],
        [-10,  0, 10, 10, 10, 10,  0,-10],
        [-10, 10, 10, 10, 10, 10, 10,-10],
        [-10,  5,  0,  0,  0,  0,  5,-10],
        [-20,-10,-10,-10,-10,-10,-10,-20]
      ],
      'rook': [
        [0,  0,  0,  0,  0,  0,  0,  0],
        [5, 10, 10, 10, 10, 10, 10,  5],
        [-5,  0,  0,  0,  0,  0,  0, -5],
        [-5,  0,  0,  0,  0,  0,  0, -5],
        [-5,  0,  0,  0,  0,  0,  0, -5],
        [-5,  0,  0,  0,  0,  0,  0, -5],
        [-5,  0,  0,  0,  0,  0,  0, -5],
        [0,  0,  0,  5,  5,  0,  0,  0]
      ],
      'queen': [
        [-20,-10,-10, -5, -5,-10,-10,-20],
        [-10,  0,  0,  0,  0,  0,  0,-10],
        [-10,  0,  5,  5,  5,  5,  0,-10],
        [-5,  0,  5,  5,  5,  5,  0, -5],
        [0,  0,  5,  5,  5,  5,  0, -5],
        [-10,  5,  5,  5,  5,  5,  0,-10],
        [-10,  0,  5,  0,  0,  0,  0,-10],
        [-20,-10,-10, -5, -5,-10,-10,-20]
      ],
      'king': [
        [-30,-40,-40,-50,-50,-40,-40,-30],
        [-30,-40,-40,-50,-50,-40,-40,-30],
        [-30,-40,-40,-50,-50,-40,-40,-30],
        [-30,-40,-40,-50,-50,-40,-40,-30],
        [-20,-30,-30,-40,-40,-30,-30,-20],
        [-10,-20,-20,-20,-20,-20,-20,-10],
        [20, 20,  0,  0,  0,  0, 20, 20],
        [20, 30, 10,  0,  0, 10, 30, 20]
      ]
    };
  }

  // Convert square notation to coordinates
  squareToCoords(square) {
    if (!square || square.length !== 2) return null;
    const file = square.charCodeAt(0) - 97; // a=0, b=1, etc.
    const rank = parseInt(square[1]) - 1; // 1=0, 2=1, etc.
    return { file, rank };
  }

  // Convert coordinates to square notation
  coordsToSquare(file, rank) {
    if (file < 0 || file > 7 || rank < 0 || rank > 7) return null;
    return String.fromCharCode(97 + file) + (rank + 1);
  }

  // Get piece at square
  getPieceAt(position, square) {
    return position.pieces.find(p => p.square === square);
  }

  // Check if square is attacked by opponent
  isSquareAttacked(position, square, byColor) {
    const attackers = position.pieces.filter(p => p.color === byColor);
    
    for (const attacker of attackers) {
      const moves = this.getPieceMoves(position, attacker, false);
      if (moves.some(m => m.to === square)) {
        return true;
      }
    }
    
    return false;
  }

  // Generate all legal moves for a piece
  getPieceMoves(position, piece, checkLegality = true) {
    const moves = [];
    const coords = this.squareToCoords(piece.square);
    if (!coords) return moves;

    const { file, rank } = coords;
    const opponentColor = piece.color === 'white' ? 'black' : 'white';

    switch (piece.type) {
      case 'pawn':
        const direction = piece.color === 'white' ? 1 : -1;
        const startRank = piece.color === 'white' ? 1 : 6;
        
        // Move forward one square
        const oneForward = this.coordsToSquare(file, rank + direction);
        if (oneForward && !this.getPieceAt(position, oneForward)) {
          moves.push({ from: piece.square, to: oneForward, type: 'move' });
          
          // Move forward two squares from starting position
          if (rank === startRank) {
            const twoForward = this.coordsToSquare(file, rank + 2 * direction);
            if (twoForward && !this.getPieceAt(position, twoForward)) {
              moves.push({ from: piece.square, to: twoForward, type: 'move' });
            }
          }
        }
        
        // Captures
        [-1, 1].forEach(offset => {
          const captureSquare = this.coordsToSquare(file + offset, rank + direction);
          const target = this.getPieceAt(position, captureSquare);
          if (target && target.color === opponentColor) {
            moves.push({ from: piece.square, to: captureSquare, type: 'capture', captured: target.type });
          }
        });
        break;

      case 'knight':
        const knightMoves = [
          [-2, -1], [-2, 1], [-1, -2], [-1, 2],
          [1, -2], [1, 2], [2, -1], [2, 1]
        ];
        knightMoves.forEach(([df, dr]) => {
          const targetSquare = this.coordsToSquare(file + df, rank + dr);
          if (targetSquare) {
            const target = this.getPieceAt(position, targetSquare);
            if (!target) {
              moves.push({ from: piece.square, to: targetSquare, type: 'move' });
            } else if (target.color === opponentColor) {
              moves.push({ from: piece.square, to: targetSquare, type: 'capture', captured: target.type });
            }
          }
        });
        break;

      case 'bishop':
        this.addSlidingMoves(position, piece, [[1,1], [1,-1], [-1,1], [-1,-1]], moves);
        break;

      case 'rook':
        this.addSlidingMoves(position, piece, [[0,1], [0,-1], [1,0], [-1,0]], moves);
        break;

      case 'queen':
        this.addSlidingMoves(position, piece, [
          [0,1], [0,-1], [1,0], [-1,0],
          [1,1], [1,-1], [-1,1], [-1,-1]
        ], moves);
        break;

      case 'king':
        const kingMoves = [
          [-1,-1], [-1,0], [-1,1], [0,-1],
          [0,1], [1,-1], [1,0], [1,1]
        ];
        kingMoves.forEach(([df, dr]) => {
          const targetSquare = this.coordsToSquare(file + df, rank + dr);
          if (targetSquare) {
            const target = this.getPieceAt(position, targetSquare);
            if (!target) {
              moves.push({ from: piece.square, to: targetSquare, type: 'move' });
            } else if (target.color === opponentColor) {
              moves.push({ from: piece.square, to: targetSquare, type: 'capture', captured: target.type });
            }
          }
        });
        break;
    }

    return moves;
  }

  addSlidingMoves(position, piece, directions, moves) {
    const coords = this.squareToCoords(piece.square);
    if (!coords) return;
    
    const { file, rank } = coords;
    const opponentColor = piece.color === 'white' ? 'black' : 'white';

    directions.forEach(([df, dr]) => {
      let currentFile = file + df;
      let currentRank = rank + dr;
      
      while (currentFile >= 0 && currentFile <= 7 && currentRank >= 0 && currentRank <= 7) {
        const targetSquare = this.coordsToSquare(currentFile, currentRank);
        const target = this.getPieceAt(position, targetSquare);
        
        if (!target) {
          moves.push({ from: piece.square, to: targetSquare, type: 'move' });
        } else {
          if (target.color === opponentColor) {
            moves.push({ from: piece.square, to: targetSquare, type: 'capture', captured: target.type });
          }
          break; // Can't move past any piece
        }
        
        currentFile += df;
        currentRank += dr;
      }
    });
  }

  // Evaluate position score
  evaluatePosition(position, forColor) {
    let score = 0;
    
    position.pieces.forEach(piece => {
      const pieceValue = this.pieceValues[piece.type];
      const coords = this.squareToCoords(piece.square);
      
      if (coords) {
        let posValue = 0;
        if (this.positionBonus[piece.type]) {
          const rankIndex = piece.color === 'white' ? coords.rank : 7 - coords.rank;
          posValue = this.positionBonus[piece.type][rankIndex][coords.file];
        }
        
        const totalValue = pieceValue + posValue;
        
        if (piece.color === forColor) {
          score += totalValue;
        } else {
          score -= totalValue;
        }
      }
    });
    
    return score;
  }

  // Evaluate a single move
  evaluateMove(position, move, playerColor) {
    let score = 0;
    const piece = this.getPieceAt(position, move.from);
    
    if (!piece) return 0;

    // Capture value
    if (move.type === 'capture') {
      score += this.pieceValues[move.captured] * 10;
      
      // Good trade detection
      const attackerValue = this.pieceValues[piece.type];
      const capturedValue = this.pieceValues[move.captured];
      
      if (capturedValue >= attackerValue) {
        score += 50; // Bonus for equal or winning trade
      }
    }

    // Center control (e4, d4, e5, d5)
    const centerSquares = ['e4', 'd4', 'e5', 'd5'];
    if (centerSquares.includes(move.to)) {
      score += 30;
    }

    // Development bonus (moving pieces from starting positions)
    const backRank = piece.color === 'white' ? '1' : '8';
    if (move.from.includes(backRank) && !move.to.includes(backRank)) {
      score += 20;
    }

    // Position improvement
    const fromCoords = this.squareToCoords(move.from);
    const toCoords = this.squareToCoords(move.to);
    
    if (fromCoords && toCoords && this.positionBonus[piece.type]) {
      const fromRank = piece.color === 'white' ? fromCoords.rank : 7 - fromCoords.rank;
      const toRank = piece.color === 'white' ? toCoords.rank : 7 - toCoords.rank;
      
      const fromValue = this.positionBonus[piece.type][fromRank][fromCoords.file];
      const toValue = this.positionBonus[piece.type][toRank][toCoords.file];
      
      score += (toValue - fromValue);
    }

    // Penalty if piece moves to attacked square
    const opponentColor = playerColor === 'white' ? 'black' : 'white';
    if (this.isSquareAttacked(position, move.to, opponentColor)) {
      score -= this.pieceValues[piece.type] / 20;
    }

    return score;
  }

  // Get best moves for a color
  getBestMoves(position, playerColor, count = 5) {
    const playerPieces = position.pieces.filter(p => p.color === playerColor);
    const allMoves = [];

    playerPieces.forEach(piece => {
      const moves = this.getPieceMoves(position, piece);
      moves.forEach(move => {
        const score = this.evaluateMove(position, move, playerColor);
        allMoves.push({
          ...move,
          piece: piece.type,
          score: score
        });
      });
    });

    // Sort by score and return top moves
    allMoves.sort((a, b) => b.score - a.score);
    return allMoves.slice(0, count);
  }

  // Get move description in Vietnamese
  getMoveDescription(move) {
    const pieceNames = {
      'pawn': 'Tốt',
      'knight': 'Mã',
      'bishop': 'Tượng',
      'rook': 'Xe',
      'queen': 'Hậu',
      'king': 'Vua'
    };

    let description = `${pieceNames[move.piece]} ${move.from} → ${move.to}`;
    
    if (move.type === 'capture') {
      description += ` (ăn ${pieceNames[move.captured]})`;
    }

    return description;
  }

  // Get tactical reason for move
  getMoveReason(move) {
    const reasons = [];

    if (move.type === 'capture') {
      const captureValue = this.pieceValues[move.captured];
      if (captureValue >= 300) {
        reasons.push('🎯 Ăn quân giá trị cao');
      } else {
        reasons.push('⚔️ Ăn quân');
      }
    }

    const centerSquares = ['e4', 'd4', 'e5', 'd5'];
    if (centerSquares.includes(move.to)) {
      reasons.push('📍 Kiểm soát trung tâm');
    }

    if (move.score > 100) {
      reasons.push('⭐ Nước đi mạnh');
    } else if (move.score > 50) {
      reasons.push('✅ Nước đi tốt');
    }

    if (move.piece === 'knight' || move.piece === 'bishop') {
      reasons.push('♞ Phát triển quân');
    }

    if (reasons.length === 0) {
      reasons.push('🔄 Cải thiện vị trí');
    }

    return reasons.join(' • ');
  }
}
