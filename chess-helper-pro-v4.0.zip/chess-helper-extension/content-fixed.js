// Chess.com Move Helper - Fixed Position Detection

class ChessMoveHelper {
  constructor() {
    this.enabled = false;
    this.board = null;
    this.suggestionsPanel = null;
    this.currentPosition = null;
    this.lastMoveCount = 0;
    this.engine = new ChessEngine();
    this.highlightedSquares = [];
    this.autoUpdateEnabled = true;
    this.updateInterval = null;
    this.init();
  }

  init() {
    console.log('♟️ Chess Move Helper v3.1 - Fixed Position Detection');
    this.createUI();
    this.waitForBoard();
  }

  createUI() {
    this.suggestionsPanel = document.createElement('div');
    this.suggestionsPanel.id = 'chess-helper-panel';
    this.suggestionsPanel.innerHTML = `
      <div class="chess-helper-header">
        <h3>🤖 Trợ Lý Cờ Vua Pro</h3>
        <div class="header-controls">
          <button id="toggle-helper" class="helper-toggle">Bật</button>
          <button id="toggle-auto" class="helper-auto active" title="Tự động cập nhật">🔄</button>
        </div>
      </div>
      <div class="chess-helper-content">
        <div class="position-eval" id="position-eval">
          <div class="eval-bar">
            <div class="eval-fill" id="eval-fill"></div>
          </div>
          <div class="eval-score" id="eval-score">+0.0</div>
        </div>
        <div id="suggestions-list">
          <p class="helper-hint">Nhấn "Bật" để nhận gợi ý nước đi thông minh</p>
        </div>
        <div class="helper-status" id="helper-status"></div>
      </div>
    `;

    document.body.appendChild(this.suggestionsPanel);

    document.getElementById('toggle-helper').addEventListener('click', () => this.toggleHelper());
    document.getElementById('toggle-auto').addEventListener('click', () => this.toggleAutoUpdate());
  }

  toggleHelper() {
    this.enabled = !this.enabled;
    const toggleBtn = document.getElementById('toggle-helper');
    toggleBtn.textContent = this.enabled ? 'Tắt' : 'Bật';
    toggleBtn.classList.toggle('active', this.enabled);

    if (this.enabled) {
      this.showStatus('🔍 Đang phân tích bàn cờ...');
      setTimeout(() => this.analyzePosition(), 500);
      
      if (this.autoUpdateEnabled) {
        this.startAutoUpdate();
      }
    } else {
      this.clearSuggestions();
      this.clearHighlights();
      this.showStatus('');
      this.stopAutoUpdate();
    }
  }

  toggleAutoUpdate() {
    this.autoUpdateEnabled = !this.autoUpdateEnabled;
    const autoBtn = document.getElementById('toggle-auto');
    autoBtn.classList.toggle('active', this.autoUpdateEnabled);
    autoBtn.title = this.autoUpdateEnabled ? 'Tự động cập nhật: BẬT' : 'Tự động cập nhật: TẮT';

    if (this.enabled) {
      if (this.autoUpdateEnabled) {
        this.startAutoUpdate();
        this.showStatus('✅ Tự động cập nhật: BẬT');
      } else {
        this.stopAutoUpdate();
        this.showStatus('⏸️ Tự động cập nhật: TẮT');
      }
    }
  }

  startAutoUpdate() {
    this.stopAutoUpdate();
    
    this.updateInterval = setInterval(() => {
      if (this.enabled) {
        this.checkForUpdates();
      }
    }, 1000);
    
    console.log('🔄 Auto-update started');
  }

  stopAutoUpdate() {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
      this.updateInterval = null;
      console.log('⏸️ Auto-update stopped');
    }
  }

  checkForUpdates() {
    const position = this.getBoardPosition();
    
    if (!position || position.pieces.length === 0) {
      return;
    }

    const currentHash = this.getPositionHash(position);
    const lastHash = this.currentPosition ? this.getPositionHash(this.currentPosition) : null;

    if (currentHash !== lastHash) {
      console.log('🔔 Position changed detected!');
      this.analyzePosition();
    }
  }

  getPositionHash(position) {
    return position.pieces
      .map(p => `${p.type}${p.color}${p.square}`)
      .sort()
      .join('|');
  }

  waitForBoard() {
    let attempts = 0;
    const maxAttempts = 30;
    
    const checkBoard = setInterval(() => {
      attempts++;
      
      const selectors = [
        'chess-board',
        '.board',
        '[class*="board-"]',
        '#board-layout-main',
        '[id*="board"]',
        '.game-board'
      ];
      
      let boardFound = false;
      
      for (const selector of selectors) {
        const board = document.querySelector(selector);
        if (board) {
          console.log(`✅ Found board with: ${selector}`);
          this.board = board;
          boardFound = true;
          this.observeBoardChanges();
          clearInterval(checkBoard);
          this.showStatus('✅ Đã kết nối với bàn cờ');
          break;
        }
      }
      
      if (!boardFound && attempts >= maxAttempts) {
        console.log('❌ Board not found');
        clearInterval(checkBoard);
        this.showStatus('⚠️ Không tìm thấy bàn cờ. Vui lòng refresh trang.');
      }
    }, 500);
  }

  observeBoardChanges() {
    if (!this.board) return;
    
    const observer = new MutationObserver((mutations) => {
      if (this.enabled && !this.autoUpdateEnabled) {
        this.lastMoveCount++;
        console.log('📝 Move detected via observer');
        setTimeout(() => this.analyzePosition(), 300);
      }
    });

    observer.observe(this.board, {
      childList: true,
      subtree: true,
      attributes: true,
      characterData: true
    });
    
    console.log('👀 Board observer active');
  }

  analyzePosition() {
    try {
      console.log('🔍 Analyzing position...');
      const position = this.getBoardPosition();
      
      if (!position || position.pieces.length === 0) {
        this.showMessage('⏳ Đang chờ bàn cờ...');
        return;
      }

      console.log(`✅ Found ${position.pieces.length} pieces`);
      console.log('📋 Position:', position.pieces);
      
      this.currentPosition = position;
      
      const evaluation = this.engine.evaluatePosition(position, position.isPlayerWhite ? 'white' : 'black');
      this.updateEvaluation(evaluation);
      
      const playerColor = position.isPlayerWhite ? 'white' : 'black';
      const suggestions = this.engine.getBestMoves(position, playerColor, 6);
      
      this.displaySuggestions(suggestions, position);
      
      this.showStatus(`♟️ Đã phân tích ${position.pieces.length} quân • Tìm thấy ${suggestions.length} nước đi`);
      
    } catch (error) {
      console.error('❌ Analysis error:', error);
      this.showMessage('❌ Lỗi phân tích: ' + error.message);
    }
  }

  updateEvaluation(score) {
    const scoreEl = document.getElementById('eval-score');
    const fillEl = document.getElementById('eval-fill');
    
    if (!scoreEl || !fillEl) return;

    const displayScore = (score / 100).toFixed(1);
    scoreEl.textContent = score >= 0 ? `+${displayScore}` : displayScore;
    
    const percentage = Math.max(0, Math.min(100, 50 + (score / 50)));
    fillEl.style.width = percentage + '%';
    
    if (score > 200) {
      fillEl.style.backgroundColor = '#4caf50';
      scoreEl.style.color = '#4caf50';
    } else if (score < -200) {
      fillEl.style.backgroundColor = '#f44336';
      scoreEl.style.color = '#f44336';
    } else {
      fillEl.style.backgroundColor = '#ffc107';
      scoreEl.style.color = '#ffc107';
    }
  }

  getBoardPosition() {
    console.log('🔎 Detecting pieces using improved method...');
    
    // Phương pháp 1: Tìm qua class attributes (Chess.com format)
    let allPieces = [];
    
    // Thử tìm trong shadow DOM trước (Chess.com thường dùng)
    const chessBoard = document.querySelector('chess-board');
    if (chessBoard?.shadowRoot) {
      console.log('🔍 Searching in shadow DOM...');
      allPieces = this.getPiecesFromShadowDOM(chessBoard.shadowRoot);
    }
    
    // Nếu không tìm thấy, thử tìm trong main DOM
    if (allPieces.length === 0) {
      console.log('🔍 Searching in main DOM...');
      allPieces = this.getPiecesFromMainDOM();
    }
    
    if (allPieces.length === 0) {
      console.log('⚠️ No pieces found');
      return { pieces: [], turn: true, isPlayerWhite: true };
    }

    console.log(`✅ Found ${allPieces.length} piece elements`);
    
    const position = {
      pieces: [],
      turn: this.getPlayerTurn(),
      isPlayerWhite: this.isPlayerWhite()
    };

    // Parse từng quân cờ
    allPieces.forEach((pieceEl, index) => {
      const pieceData = this.parsePieceFromElement(pieceEl);
      
      if (pieceData) {
        position.pieces.push(pieceData);
        console.log(`  ${index + 1}. ${pieceData.color} ${pieceData.type} at ${pieceData.square}`);
      }
    });

    console.log(`📊 Successfully parsed ${position.pieces.length} pieces`);
    return position;
  }

  getPiecesFromShadowDOM(shadowRoot) {
    const pieces = [];
    
    // Chess.com shadow DOM selectors
    const selectors = [
      '.piece',
      '[class*="piece"]',
      '[data-piece]',
      'piece'
    ];
    
    for (const selector of selectors) {
      const elements = shadowRoot.querySelectorAll(selector);
      if (elements.length > 0) {
        console.log(`  Found ${elements.length} with ${selector} in shadow DOM`);
        return Array.from(elements);
      }
    }
    
    return pieces;
  }

  getPiecesFromMainDOM() {
    const selectors = [
      '.piece',
      '[class*="piece"]',
      '[class^="piece-"]',
      'piece',
      '.chess-piece',
      '[data-piece]'
    ];
    
    for (const selector of selectors) {
      const pieces = document.querySelectorAll(selector);
      if (pieces.length > 0) {
        console.log(`  Found ${pieces.length} with ${selector} in main DOM`);
        return Array.from(pieces);
      }
    }
    
    return [];
  }

  parsePieceFromElement(element) {
    // Lấy thông tin từ class names
    const classes = element.className || '';
    const classList = classes.split(' ');
    
    // Log để debug
    console.log('  Parsing element:', {
      classes: classes,
      attributes: {
        piece: element.getAttribute('data-piece'),
        square: element.getAttribute('data-square'),
        color: element.getAttribute('data-color')
      },
      style: element.style.transform
    });
    
    // Phương pháp 1: Từ class names (Chess.com format: square-XX, piece type, color)
    let square = null;
    let pieceType = null;
    let color = null;
    
    // Tìm square từ class
    for (const cls of classList) {
      // Format: square-11, square-77, square-85, etc.
      const squareMatch = cls.match(/square-(\d)(\d)/);
      if (squareMatch) {
        const file = parseInt(squareMatch[1]) - 1; // 1-8 -> 0-7
        const rank = parseInt(squareMatch[2]);     // 1-8
        
        if (file >= 0 && file <= 7 && rank >= 1 && rank <= 8) {
          square = String.fromCharCode(97 + file) + rank;
          console.log(`    Found square from class ${cls}: ${square} (file=${file+1}, rank=${rank})`);
          break;
        }
      }
    }
    
    // Tìm piece type và color từ class
    // Chess.com format: "wp", "bp", "wn", "bn", etc.
    const lowerClasses = classes.toLowerCase();
    
    // Parse piece type và color từ 2-character codes
    const pieceMatch = lowerClasses.match(/\b([wb])([pnbrqk])\b/);
    if (pieceMatch) {
      const colorCode = pieceMatch[1]; // 'w' or 'b'
      const typeCode = pieceMatch[2];  // 'p', 'n', 'b', 'r', 'q', 'k'
      
      color = colorCode === 'w' ? 'white' : 'black';
      
      switch (typeCode) {
        case 'p': pieceType = 'pawn'; break;
        case 'n': pieceType = 'knight'; break;
        case 'b': pieceType = 'bishop'; break;
        case 'r': pieceType = 'rook'; break;
        case 'q': pieceType = 'queen'; break;
        case 'k': pieceType = 'king'; break;
      }
    }
    
    // Fallback: kiểm tra từng class riêng lẻ
    if (!pieceType || !color) {
      for (const cls of classList) {
        const lower = cls.toLowerCase();
        
        // Piece type
        if (!pieceType) {
          if (lower.includes('pawn') || lower === 'p') pieceType = 'pawn';
          else if (lower.includes('knight') || lower === 'n') pieceType = 'knight';
          else if (lower.includes('bishop') || lower === 'b') pieceType = 'bishop';
          else if (lower.includes('rook') || lower === 'r') pieceType = 'rook';
          else if (lower.includes('queen') || lower === 'q') pieceType = 'queen';
          else if (lower.includes('king') || lower === 'k') pieceType = 'king';
        }
        
        // Color
        if (!color) {
          if (lower.includes('white') || lower === 'w') color = 'white';
          else if (lower.includes('black')) color = 'black';
        }
      }
    }
    
    // Phương pháp 2: Từ data attributes
    if (!square) {
      const squareAttr = element.getAttribute('data-square') || element.getAttribute('square');
      if (squareAttr && /^[a-h][1-8]$/.test(squareAttr)) {
        square = squareAttr;
        console.log(`    Found square from attribute: ${square}`);
      }
    }
    
    if (!pieceType) {
      const pieceAttr = element.getAttribute('data-piece') || element.getAttribute('piece');
      if (pieceAttr) {
        const p = pieceAttr.toLowerCase();
        if (p.includes('pawn')) pieceType = 'pawn';
        else if (p.includes('knight')) pieceType = 'knight';
        else if (p.includes('bishop')) pieceType = 'bishop';
        else if (p.includes('rook')) pieceType = 'rook';
        else if (p.includes('queen')) pieceType = 'queen';
        else if (p.includes('king')) pieceType = 'king';
      }
    }
    
    if (!color) {
      const colorAttr = element.getAttribute('data-color') || element.getAttribute('color');
      if (colorAttr) {
        color = colorAttr.toLowerCase().includes('white') ? 'white' : 'black';
      }
    }
    
    // Phương pháp 3: Từ style.transform (vị trí pixel -> square)
    if (!square) {
      square = this.getSquareFromTransform(element);
      if (square) {
        console.log(`    Found square from transform: ${square}`);
      }
    }
    
    // Validate và return
    if (pieceType && color && square) {
      console.log(`    ✅ Parsed: ${color} ${pieceType} at ${square}`);
      return { type: pieceType, color: color, square: square };
    } else {
      console.log(`    ❌ Failed to parse: type=${pieceType}, color=${color}, square=${square}`);
      return null;
    }
  }

  getSquareFromTransform(element) {
    const style = window.getComputedStyle(element);
    const transform = style.transform;
    
    if (!transform || transform === 'none') {
      return null;
    }
    
    // Parse transform matrix
    const match = transform.match(/matrix\(([^)]+)\)/);
    if (match) {
      const values = match[1].split(',').map(v => parseFloat(v.trim()));
      if (values.length >= 6) {
        const x = values[4]; // translateX
        const y = values[5]; // translateY
        
        // Lấy kích thước bàn cờ
        const boardEl = this.board || document.querySelector('chess-board') || document.querySelector('.board');
        if (!boardEl) return null;
        
        const boardRect = boardEl.getBoundingClientRect();
        const squareSize = boardRect.width / 8;
        
        // Tính file và rank
        const file = Math.floor(Math.abs(x) / squareSize);
        const rank = Math.floor(Math.abs(y) / squareSize);
        
        // Điều chỉnh cho board flipped
        const isFlipped = this.board && this.board.className.includes('flipped');
        
        let finalFile = file;
        let finalRank = rank;
        
        if (isFlipped) {
          finalFile = 7 - file;
          finalRank = rank;
        } else {
          finalRank = 7 - rank;
        }
        
        if (finalFile >= 0 && finalFile <= 7 && finalRank >= 0 && finalRank <= 7) {
          return String.fromCharCode(97 + finalFile) + (finalRank + 1);
        }
      }
    }
    
    return null;
  }

  getPlayerTurn() {
    const indicators = [
      '.clock-player-turn',
      '[class*="clock"][class*="active"]',
      '.player-turn',
      '[class*="turn"]'
    ];
    
    for (const selector of indicators) {
      if (document.querySelector(selector)) {
        return true;
      }
    }
    
    return true;
  }

  isPlayerWhite() {
    const board = this.board;
    if (!board) return true;
    
    const classes = board.className || '';
    return !classes.includes('flipped');
  }

  displaySuggestions(suggestions, position) {
    const container = document.getElementById('suggestions-list');
    
    if (suggestions.length === 0) {
      container.innerHTML = '<p class="helper-hint">Không tìm thấy nước đi hợp lệ</p>';
      return;
    }

    let html = '<div class="suggestions">';
    suggestions.forEach((move, index) => {
      const description = this.engine.getMoveDescription(move);
      const reason = this.engine.getMoveReason(move);
      const scoreDisplay = move.score > 0 ? `+${move.score}` : move.score;
      
      let icon = '♟️';
      if (move.type === 'capture') icon = '⚔️';
      else if (move.score > 100) icon = '⭐';
      else if (move.score > 50) icon = '✨';
      
      html += `
        <div class="suggestion-item" data-from="${move.from}" data-to="${move.to}" onclick="window.chessMoveHelper.highlightMove('${move.from}', '${move.to}')">
          <div class="suggestion-number">${index + 1}</div>
          <div class="suggestion-details">
            <div class="suggestion-move">
              ${icon} ${description}
              <span class="move-score">${scoreDisplay}</span>
            </div>
            <div class="suggestion-reason">${reason}</div>
          </div>
        </div>
      `;
    });
    html += '</div>';

    container.innerHTML = html;
  }

  highlightMove(fromSquare, toSquare) {
    console.log(`🎯 Highlighting move: ${fromSquare} → ${toSquare}`);
    
    this.clearHighlights();
    
    const fromEl = this.findSquareElement(fromSquare);
    const toEl = this.findSquareElement(toSquare);
    
    if (fromEl) {
      fromEl.classList.add('chess-helper-highlight-from');
      this.highlightedSquares.push(fromEl);
    }
    
    if (toEl) {
      toEl.classList.add('chess-helper-highlight-to');
      this.highlightedSquares.push(toEl);
    }
    
    setTimeout(() => this.clearHighlights(), 3000);
  }

  findSquareElement(square) {
    const selectors = [
      `[data-square="${square}"]`,
      `.square-${square}`,
      `[square="${square}"]`
    ];
    
    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el) return el;
    }
    
    const chessBoard = document.querySelector('chess-board');
    if (chessBoard?.shadowRoot) {
      for (const selector of selectors) {
        const el = chessBoard.shadowRoot.querySelector(selector);
        if (el) return el;
      }
    }
    
    return null;
  }

  clearHighlights() {
    this.highlightedSquares.forEach(el => {
      el.classList.remove('chess-helper-highlight-from');
      el.classList.remove('chess-helper-highlight-to');
    });
    this.highlightedSquares = [];
  }

  showMessage(message) {
    const container = document.getElementById('suggestions-list');
    container.innerHTML = `<p class="helper-hint">${message}</p>`;
  }

  showStatus(status) {
    const statusEl = document.getElementById('helper-status');
    if (statusEl) {
      statusEl.textContent = status;
      statusEl.style.display = status ? 'block' : 'none';
    }
  }

  clearSuggestions() {
    const container = document.getElementById('suggestions-list');
    container.innerHTML = '<p class="helper-hint">Trợ lý đã tắt</p>';
  }
}

window.chessMoveHelper = null;

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 Initializing Fixed Chess Helper');
    window.chessMoveHelper = new ChessMoveHelper();
  });
} else {
  console.log('🚀 Initializing Fixed Chess Helper');
  window.chessMoveHelper = new ChessMoveHelper();
}
