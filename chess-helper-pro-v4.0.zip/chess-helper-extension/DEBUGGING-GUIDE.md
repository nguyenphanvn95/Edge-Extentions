# Hướng Dẫn Debug Chess Helper Extension

## 🔍 Cách Kiểm Tra Extension Đang Hoạt Động

### 1. Mở Chrome DevTools Console
- Vào Chess.com
- Nhấn `F12` hoặc `Ctrl+Shift+I` (Windows) / `Cmd+Option+I` (Mac)
- Chọn tab "Console"

### 2. Kiểm Tra Extension Đã Load
Bạn sẽ thấy các log như:
```
♟️ Chess Move Helper v3.1 - Fixed Position Detection
✅ Found board with: chess-board
👀 Board observer active
```

### 3. Khi Bật Trợ Lý
Click nút "Bật" và xem console:
```
🔍 Analyzing position...
🔎 Detecting pieces using improved method...
🔍 Searching in shadow DOM...
  Found 32 with .piece in shadow DOM
✅ Found 32 piece elements
  Parsing element: {...}
    Found square from class: e2
    ✅ Parsed: white pawn at e2
  Parsing element: {...}
    Found square from class: d7
    ✅ Parsed: black pawn at d7
...
📊 Successfully parsed 32 pieces
```

### 4. Kiểm Tra Vị Trí Quân Cờ
Trong console, gõ:
```javascript
window.chessMoveHelper.currentPosition
```

Bạn sẽ thấy object như:
```javascript
{
  pieces: [
    {type: "pawn", color: "white", square: "e2"},
    {type: "knight", color: "white", square: "g1"},
    {type: "rook", color: "black", square: "a8"},
    ...
  ],
  turn: true,
  isPlayerWhite: true
}
```

### 5. Test Một Nước Đi Cụ Thể
```javascript
// Lấy vị trí hiện tại
const pos = window.chessMoveHelper.currentPosition;

// Kiểm tra một quân cụ thể
pos.pieces.filter(p => p.type === 'queen')
// Kết quả: [{type: "queen", color: "white", square: "d1"}, ...]

// Test engine
const moves = window.chessMoveHelper.engine.getBestMoves(pos, 'white', 5);
console.log(moves);
```

## 🐛 Các Vấn Đề Thường Gặp

### Vấn Đề 1: Không Tìm Thấy Quân Cờ
**Triệu chứng:**
```
⚠️ No pieces found
📊 Successfully parsed 0 pieces
```

**Nguyên nhân:** Chess.com có thể thay đổi cấu trúc HTML

**Cách fix:**
1. Mở DevTools
2. Chọn tab "Elements"
3. Inspect một quân cờ bất kỳ
4. Xem class names và attributes:
   ```html
   <div class="piece wp square-52" data-piece="wp" data-square="e2">
   ```
5. Cập nhật selectors trong `getPiecesFromShadowDOM()` hoặc `getPiecesFromMainDOM()`

### Vấn Đề 2: Vị Trí Sai
**Triệu chứng:**
- Panel hiển thị "Hậu f3 → h1" nhưng không có Hậu ở f3

**Nguyên nhân:** Parse vị trí square sai

**Cách debug:**
1. Trong console, kiểm tra parse:
```javascript
// Lấy một quân cờ element
const piece = document.querySelector('.piece');
console.log({
  classes: piece.className,
  attributes: {
    square: piece.getAttribute('data-square'),
    piece: piece.getAttribute('data-piece')
  },
  style: piece.style.transform
});
```

2. Kiểm tra format square trong class:
```javascript
// Nếu class là "square-52"
// File = 5-1 = 4 → 'e'
// Rank = 2 → '2'
// Square = "e2" ✅
```

3. Nếu sai, cập nhật logic trong `parsePieceFromElement()`

### Vấn Đề 3: Board Flipped (Bàn Cờ Lật Ngược)
**Triệu chứng:** Quân đen ở dưới, quân trắng ở trên

**Cách kiểm tra:**
```javascript
window.chessMoveHelper.isPlayerWhite()
// false = Bạn chơi quân đen, board bị flipped
```

**Fix:** Logic đã xử lý trong `getSquareFromTransform()` với biến `isFlipped`

### Vấn Đề 4: Gợi Ý Không Hợp Lệ
**Triệu chứng:** Gợi ý "Mã a1 → c2" nhưng không có Mã ở a1

**Cách debug:**
```javascript
const pos = window.chessMoveHelper.currentPosition;
const engine = window.chessMoveHelper.engine;

// Kiểm tra quân ở a1
const pieceAtA1 = engine.getPieceAt(pos, 'a1');
console.log('Piece at a1:', pieceAtA1);

// Kiểm tra tất cả Knights
const knights = pos.pieces.filter(p => p.type === 'knight');
console.log('All knights:', knights);

// Test moves cho một quân cụ thể
const knight = knights[0];
const moves = engine.getPieceMoves(pos, knight);
console.log('Knight moves:', moves);
```

## 🛠️ Cách Sửa Lỗi Nhanh

### Nếu Selectors Không Đúng:

**File: `content-fixed.js`**

Tìm hàm `getPiecesFromShadowDOM()` và thêm selector mới:
```javascript
const selectors = [
  '.piece',
  '[class*="piece"]',
  '[data-piece]',
  'piece',
  // THÊM SELECTOR MỚI Ở ĐÂY
  '.your-new-selector'
];
```

### Nếu Square Format Khác:

**File: `content-fixed.js`**

Tìm hàm `parsePieceFromElement()` và thêm logic mới:
```javascript
// Thêm vào phần parse square
const squareMatch = cls.match(/your-new-pattern-(\d)(\d)/);
if (squareMatch) {
  // Logic parse của bạn
}
```

### Nếu Cần Debug Chi Tiết:

Thêm log vào các hàm quan trọng:
```javascript
getBoardPosition() {
  console.log('=== START POSITION DETECTION ===');
  // ... existing code
  console.log('=== END POSITION DETECTION ===');
}
```

## 📊 Cấu Trúc HTML Chess.com (Tham Khảo)

### Shadow DOM Structure:
```html
<chess-board class="board">
  #shadow-root
    <div class="pieces">
      <div class="piece wp square-52" data-piece="wp" data-square="e2"></div>
      <div class="piece bp square-57" data-piece="bp" data-square="e7"></div>
      ...
    </div>
</chess-board>
```

### Class Format:
- `wp` = White Pawn
- `bn` = Black Knight
- `wb` = White Bishop
- `square-52` = Square e2 (file=5, rank=2)
- `square-57` = Square e7 (file=5, rank=7)

### Data Attributes:
- `data-piece="wp"` = White Pawn
- `data-square="e2"` = Square e2
- `data-color="white"` = White color

## 🔄 Hot Reload Extension

Sau khi sửa code:
1. Vào `chrome://extensions/`
2. Click nút reload (🔄) của extension
3. Refresh trang Chess.com
4. Kiểm tra console logs

## 📝 Checklist Debug

- [ ] Extension đã load? (Check console log)
- [ ] Board element đã tìm thấy? (✅ Found board with...)
- [ ] Số lượng quân cờ đúng? (Should be ~32 at start)
- [ ] Vị trí square đúng? (Check currentPosition)
- [ ] Màu quân đúng? (white/black)
- [ ] Type quân đúng? (pawn/knight/bishop/rook/queen/king)
- [ ] Gợi ý hợp lệ? (Moves make sense)

## 🆘 Nếu Vẫn Không Hoạt Động

1. **Xuất Full Debug Info:**
```javascript
console.log('=== FULL DEBUG INFO ===');
console.log('Board:', window.chessMoveHelper.board);
console.log('Position:', window.chessMoveHelper.currentPosition);
console.log('Enabled:', window.chessMoveHelper.enabled);
console.log('Auto-update:', window.chessMoveHelper.autoUpdateEnabled);

// Test piece detection
const chessBoard = document.querySelector('chess-board');
console.log('Chess board element:', chessBoard);
console.log('Has shadow root:', !!chessBoard?.shadowRoot);
if (chessBoard?.shadowRoot) {
  console.log('Pieces in shadow:', chessBoard.shadowRoot.querySelectorAll('.piece').length);
}
```

2. **Chụp Screenshot Console và gửi để debug**

3. **Kiểm tra Chess.com có update không:**
   - Chess.com thường xuyên update UI
   - Cần update selectors định kỳ

---

Good luck debugging! 🐛🔧
