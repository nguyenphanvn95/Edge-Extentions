/* global document, window */

// **IMPORTANT** Set to "prod" before release
/** @type {"local" | "test" | "prod"} */
const environment = "prod";

window.readlangHostname = {
  local: "localhost",
  test: "test.readlang.com",
  prod: "readlang.com",
}[environment];
window.READLANG = window.READLANG || {};

// XXX Git commit not actually set for Chrome extension
window.READLANG.gitCommit = "{{gitCommit}}";

/** Compatibility version of chrome extension, can be:
 * - boolean: true
 * - integer value greater than or equal to: 2
 */
window.READLANG.chromeExtension = 3;

/** Browser type for extension */
window.READLANG.extensionBrowser =
  typeof InstallTrigger !== "undefined" ? "firefox" : "chrome";

/**
 * Save a clone of the document in case we want to use the web importer on it.
 * The web importer will not work as well on the Readlang-spannified document.
 * Only capture this once to preserve the original unmodified document.
 */
if (!window.READLANG.originalDocument) {
  window.READLANG.originalDocument = document.cloneNode(true);
}
