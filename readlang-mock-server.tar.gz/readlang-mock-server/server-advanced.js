const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Data file path
const DATA_FILE = path.join(__dirname, 'data.json');

// Load or initialize database
let db = {
  users: {},
  userWords: {},
  chunks: {},
  books: {},
  shelves: {},
  urls: {},
  currentUserId: null
};

// Load data from file if exists
function loadData() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const rawData = fs.readFileSync(DATA_FILE, 'utf8');
      db = JSON.parse(rawData);
      console.log('✅ Loaded data from file');
    } else {
      // Initialize with default user
      initializeDefaultUser();
      saveData();
    }
  } catch (error) {
    console.error('Error loading data:', error);
    initializeDefaultUser();
  }
}

// Save data to file
function saveData() {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
  } catch (error) {
    console.error('Error saving data:', error);
  }
}

// Auto-save every 30 seconds
setInterval(saveData, 30000);

// Initialize default user
function initializeDefaultUser() {
  const defaultUser = {
    id: 'user_default',
    email: 'offline@readlang.com',
    name: 'Offline User',
    firstLanguage: 'en',
    currentLearningLanguage: 'vi',
    readerDeselectBehavior: 'keep',
    readerMergePhrases: 'on',
    readerShowTransliteration: true,
    createdAt: new Date().toISOString(),
    premium: true
  };
  
  db.users[defaultUser.id] = defaultUser;
  db.currentUserId = defaultUser.id;
}

// Helper functions
function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// Free translation API using MyMemory
async function translateWithAPI(text, fromLang, toLang) {
  try {
    const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${fromLang}|${toLang}`;
    
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.responseStatus === 200) {
      return {
        translation: data.responseData.translatedText,
        alternatives: data.matches?.slice(0, 3).map(m => m.translation) || [],
        source: 'mymemory'
      };
    }
  } catch (error) {
    console.error('Translation API error:', error);
  }
  
  return null;
}

// Fallback translation dictionary
const translationDict = {
  // Vietnamese to English
  'xin chào': 'hello',
  'cảm ơn': 'thank you',
  'tạm biệt': 'goodbye',
  'vui lòng': 'please',
  'làm ơn': 'please',
  'xin lỗi': 'sorry',
  'tôi': 'I/me',
  'bạn': 'you',
  'chúng tôi': 'we',
  'họ': 'they',
  'này': 'this',
  'đó': 'that',
  'là': 'is/am/are',
  'có': 'have/has/there is',
  'không': 'no/not',
  'gì': 'what',
  'ai': 'who',
  'ở đâu': 'where',
  'khi nào': 'when',
  'tại sao': 'why',
  'như thế nào': 'how',
  'cái': 'thing/the',
  'và': 'and',
  'hoặc': 'or',
  'nhưng': 'but',
  'vì': 'because',
  'nếu': 'if',
  'thì': 'then',
  'cũng': 'also',
  'rất': 'very',
  'lắm': 'much/very',
  'nhiều': 'much/many',
  'ít': 'few/little',
  'một': 'one/a',
  'hai': 'two',
  'ba': 'three',
  'bốn': 'four',
  'năm': 'five',
  'sáu': 'six',
  'bảy': 'seven',
  'tám': 'eight',
  'chín': 'nine',
  'mười': 'ten',
  'trăm': 'hundred',
  'nghìn': 'thousand',
  'triệu': 'million',
  'tỷ': 'billion',
  'ngày': 'day',
  'tuần': 'week',
  'tháng': 'month',
  'năm': 'year',
  'giờ': 'hour',
  'phút': 'minute',
  'giây': 'second',
  'sáng': 'morning',
  'trưa': 'noon',
  'chiều': 'afternoon',
  'tối': 'evening',
  'đêm': 'night',
  'hôm nay': 'today',
  'hôm qua': 'yesterday',
  'ngày mai': 'tomorrow',
  'ăn': 'eat',
  'uống': 'drink',
  'ngủ': 'sleep',
  'đi': 'go',
  'đến': 'come/arrive',
  'về': 'return/about',
  'làm': 'do/make',
  'học': 'learn/study',
  'dạy': 'teach',
  'nói': 'say/speak',
  'nghe': 'listen/hear',
  'nhìn': 'look/see',
  'đọc': 'read',
  'viết': 'write',
  'mua': 'buy',
  'bán': 'sell',
  'cho': 'give/for',
  'lấy': 'take/get',
  'đưa': 'give/hand',
  'nhận': 'receive',
  'muốn': 'want',
  'cần': 'need',
  'thích': 'like',
  'yêu': 'love',
  'ghét': 'hate',
  'sợ': 'fear/afraid',
  'vui': 'happy/fun',
  'buồn': 'sad',
  'giận': 'angry',
  'mệt': 'tired',
  'khỏe': 'healthy/well',
  'đau': 'hurt/pain',
  'bệnh': 'sick/disease',
  'tốt': 'good',
  'xấu': 'bad',
  'đẹp': 'beautiful',
  'to': 'big',
  'nhỏ': 'small',
  'cao': 'high/tall',
  'thấp': 'low/short',
  'dài': 'long',
  'ngắn': 'short',
  'nhanh': 'fast',
  'chậm': 'slow',
  'mới': 'new',
  'cũ': 'old',
  'trẻ': 'young',
  'già': 'old',
  'nóng': 'hot',
  'lạnh': 'cold',
  'ấm': 'warm',
  'mát': 'cool',
  'sáng': 'bright',
  'tối': 'dark',
  'trắng': 'white',
  'đen': 'black',
  'đỏ': 'red',
  'xanh': 'blue/green',
  'vàng': 'yellow',
  'nhà': 'house/home',
  'phòng': 'room',
  'bếp': 'kitchen',
  'cửa': 'door',
  'cửa sổ': 'window',
  'bàn': 'table',
  'ghế': 'chair',
  'giường': 'bed',
  'tủ': 'cabinet',
  'xe': 'vehicle/car',
  'đường': 'road',
  'thành phố': 'city',
  'nông thôn': 'countryside',
  'núi': 'mountain',
  'biển': 'sea',
  'sông': 'river',
  'cây': 'tree/plant',
  'hoa': 'flower',
  'trời': 'sky/weather',
  'mây': 'cloud',
  'mưa': 'rain',
  'nắng': 'sunny',
  'gió': 'wind',
  'gia đình': 'family',
  'bố': 'father/dad',
  'mẹ': 'mother/mom',
  'anh': 'older brother',
  'chị': 'older sister',
  'em': 'younger sibling',
  'con': 'child',
  'bạn': 'friend',
  'người': 'person/people',
  'thầy': 'teacher (male)',
  'cô': 'teacher (female)',
  'bác sĩ': 'doctor',
  'sinh viên': 'student',
  'công việc': 'work/job',
  'tiền': 'money',
  'cơm': 'rice/meal',
  'nước': 'water',
  'trà': 'tea',
  'cà phê': 'coffee',
  'sữa': 'milk',
  'bánh': 'cake/bread',
  'thịt': 'meat',
  'cá': 'fish',
  'rau': 'vegetables',
  'trái cây': 'fruit',
  
  // English to Vietnamese
  'hello': 'xin chào',
  'hi': 'chào',
  'thank you': 'cảm ơn',
  'thanks': 'cảm ơn',
  'goodbye': 'tạm biệt',
  'bye': 'tạm biệt',
  'please': 'vui lòng',
  'sorry': 'xin lỗi',
  'excuse me': 'xin lỗi',
  'yes': 'có/vâng',
  'no': 'không',
  'i': 'tôi',
  'me': 'tôi',
  'you': 'bạn',
  'we': 'chúng tôi',
  'they': 'họ',
  'he': 'anh ấy',
  'she': 'cô ấy',
  'it': 'nó',
  'this': 'này',
  'that': 'đó',
  'these': 'những cái này',
  'those': 'những cái đó',
  'is': 'là',
  'am': 'là',
  'are': 'là',
  'was': 'đã là',
  'were': 'đã là',
  'have': 'có',
  'has': 'có',
  'had': 'đã có',
  'do': 'làm',
  'does': 'làm',
  'did': 'đã làm',
  'can': 'có thể',
  'could': 'có thể',
  'will': 'sẽ',
  'would': 'sẽ',
  'should': 'nên',
  'may': 'có thể',
  'might': 'có thể',
  'must': 'phải',
  'what': 'gì',
  'who': 'ai',
  'where': 'ở đâu',
  'when': 'khi nào',
  'why': 'tại sao',
  'how': 'như thế nào',
  'which': 'cái nào',
  'and': 'và',
  'or': 'hoặc',
  'but': 'nhưng',
  'because': 'vì',
  'if': 'nếu',
  'then': 'thì',
  'so': 'vì vậy',
  'also': 'cũng',
  'too': 'cũng',
  'very': 'rất',
  'much': 'nhiều',
  'many': 'nhiều',
  'few': 'ít',
  'little': 'ít',
  'some': 'một số',
  'any': 'bất kỳ',
  'all': 'tất cả',
  'every': 'mỗi',
  'each': 'mỗi',
  'both': 'cả hai',
  'either': 'một trong hai',
  'neither': 'không cái nào',
  'one': 'một',
  'two': 'hai',
  'three': 'ba',
  'four': 'bốn',
  'five': 'năm',
  'six': 'sáu',
  'seven': 'bảy',
  'eight': 'tám',
  'nine': 'chín',
  'ten': 'mười',
  'hundred': 'trăm',
  'thousand': 'nghìn',
  'million': 'triệu',
  'billion': 'tỷ',
  'day': 'ngày',
  'week': 'tuần',
  'month': 'tháng',
  'year': 'năm',
  'hour': 'giờ',
  'minute': 'phút',
  'second': 'giây',
  'morning': 'buổi sáng',
  'afternoon': 'buổi chiều',
  'evening': 'buổi tối',
  'night': 'đêm',
  'today': 'hôm nay',
  'yesterday': 'hôm qua',
  'tomorrow': 'ngày mai',
  'now': 'bây giờ',
  'soon': 'sớm',
  'later': 'sau',
  'early': 'sớm',
  'late': 'muộn',
  'eat': 'ăn',
  'drink': 'uống',
  'sleep': 'ngủ',
  'go': 'đi',
  'come': 'đến',
  'arrive': 'đến',
  'leave': 'rời',
  'return': 'về',
  'make': 'làm',
  'learn': 'học',
  'study': 'học',
  'teach': 'dạy',
  'say': 'nói',
  'speak': 'nói',
  'talk': 'nói chuyện',
  'tell': 'kể',
  'listen': 'nghe',
  'hear': 'nghe',
  'look': 'nhìn',
  'see': 'thấy',
  'watch': 'xem',
  'read': 'đọc',
  'write': 'viết',
  'buy': 'mua',
  'sell': 'bán',
  'give': 'cho',
  'take': 'lấy',
  'get': 'lấy',
  'receive': 'nhận',
  'want': 'muốn',
  'need': 'cần',
  'like': 'thích',
  'love': 'yêu',
  'hate': 'ghét',
  'fear': 'sợ',
  'happy': 'vui',
  'sad': 'buồn',
  'angry': 'giận',
  'tired': 'mệt',
  'healthy': 'khỏe',
  'sick': 'bệnh',
  'good': 'tốt',
  'bad': 'xấu',
  'beautiful': 'đẹp',
  'ugly': 'xấu',
  'big': 'to',
  'small': 'nhỏ',
  'large': 'lớn',
  'little': 'nhỏ',
  'high': 'cao',
  'tall': 'cao',
  'low': 'thấp',
  'short': 'ngắn',
  'long': 'dài',
  'wide': 'rộng',
  'narrow': 'hẹp',
  'thick': 'dày',
  'thin': 'mỏng',
  'heavy': 'nặng',
  'light': 'nhẹ',
  'fast': 'nhanh',
  'quick': 'nhanh',
  'slow': 'chậm',
  'new': 'mới',
  'old': 'cũ',
  'young': 'trẻ',
  'hot': 'nóng',
  'cold': 'lạnh',
  'warm': 'ấm',
  'cool': 'mát',
  'bright': 'sáng',
  'dark': 'tối',
  'clean': 'sạch',
  'dirty': 'bẩn',
  'white': 'trắng',
  'black': 'đen',
  'red': 'đỏ',
  'blue': 'xanh dương',
  'green': 'xanh lá',
  'yellow': 'vàng',
  'orange': 'cam',
  'purple': 'tím',
  'pink': 'hồng',
  'brown': 'nâu',
  'gray': 'xám',
  'house': 'nhà',
  'home': 'nhà',
  'room': 'phòng',
  'kitchen': 'bếp',
  'bathroom': 'phòng tắm',
  'bedroom': 'phòng ngủ',
  'door': 'cửa',
  'window': 'cửa sổ',
  'table': 'bàn',
  'chair': 'ghế',
  'bed': 'giường',
  'sofa': 'ghế sofa',
  'car': 'xe hơi',
  'vehicle': 'xe',
  'road': 'đường',
  'street': 'phố',
  'city': 'thành phố',
  'town': 'thị trấn',
  'village': 'làng',
  'country': 'nước',
  'mountain': 'núi',
  'sea': 'biển',
  'ocean': 'đại dương',
  'river': 'sông',
  'lake': 'hồ',
  'tree': 'cây',
  'flower': 'hoa',
  'grass': 'cỏ',
  'sky': 'bầu trời',
  'cloud': 'mây',
  'rain': 'mưa',
  'sun': 'mặt trời',
  'moon': 'mặt trăng',
  'star': 'ngôi sao',
  'wind': 'gió',
  'snow': 'tuyết',
  'family': 'gia đình',
  'father': 'bố',
  'dad': 'bố',
  'mother': 'mẹ',
  'mom': 'mẹ',
  'parent': 'bố mẹ',
  'parents': 'bố mẹ',
  'child': 'con',
  'children': 'con cái',
  'son': 'con trai',
  'daughter': 'con gái',
  'brother': 'anh/em trai',
  'sister': 'chị/em gái',
  'friend': 'bạn',
  'person': 'người',
  'people': 'người',
  'man': 'đàn ông',
  'woman': 'phụ nữ',
  'boy': 'con trai',
  'girl': 'con gái',
  'baby': 'em bé',
  'teacher': 'giáo viên',
  'doctor': 'bác sĩ',
  'student': 'học sinh',
  'work': 'công việc',
  'job': 'công việc',
  'money': 'tiền',
  'food': 'thức ăn',
  'rice': 'cơm',
  'water': 'nước',
  'tea': 'trà',
  'coffee': 'cà phê',
  'milk': 'sữa',
  'bread': 'bánh mì',
  'cake': 'bánh',
  'meat': 'thịt',
  'fish': 'cá',
  'chicken': 'gà',
  'egg': 'trứng',
  'vegetable': 'rau',
  'vegetables': 'rau',
  'fruit': 'trái cây',
  'apple': 'táo',
  'banana': 'chuối',
  'orange': 'cam'
};

// Initialize data
loadData();

// ==================== AUTH ENDPOINTS ====================

app.get('/api/isAuthenticated', (req, res) => {
  if (db.currentUserId) {
    const user = db.users[db.currentUserId];
    res.json({
      authenticated: true,
      user: user
    });
  } else {
    res.json({ authenticated: false });
  }
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  
  let user = Object.values(db.users).find(u => u.email === email);
  
  if (!user) {
    user = {
      id: generateId(),
      email: email,
      name: email.split('@')[0],
      firstLanguage: 'en',
      currentLearningLanguage: 'vi',
      readerDeselectBehavior: 'keep',
      readerMergePhrases: 'on',
      readerShowTransliteration: true,
      createdAt: new Date().toISOString(),
      premium: true
    };
    db.users[user.id] = user;
  }
  
  db.currentUserId = user.id;
  saveData();
  
  const userWords = Object.values(db.userWords).filter(w => w.userId === user.id);
  
  res.json({
    success: true,
    user: user,
    userWords: userWords
  });
});

app.post('/api/logout', (req, res) => {
  db.currentUserId = null;
  saveData();
  res.json({ success: true });
});

app.post('/api/auth/googleSignIn', (req, res) => {
  const user = db.users[db.currentUserId] || db.users['user_default'];
  db.currentUserId = user.id;
  saveData();
  
  res.json({
    success: true,
    user: user
  });
});

// ==================== USER ENDPOINTS ====================

app.get('/api/user', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  res.json(db.users[db.currentUserId]);
});

app.post('/api/user', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  Object.assign(db.users[db.currentUserId], req.body);
  saveData();
  
  res.json(db.users[db.currentUserId]);
});

app.put('/api/user', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  Object.assign(db.users[db.currentUserId], req.body);
  saveData();
  
  res.json(db.users[db.currentUserId]);
});

// ==================== TRANSLATION ENDPOINTS ====================

app.get('/api/translate', async (req, res) => {
  const { q, context, from, to } = req.query;
  
  const word = (q || '').toLowerCase().trim();
  
  // Try API translation first
  const apiResult = await translateWithAPI(q, from, to);
  
  if (apiResult) {
    res.json({
      translation: apiResult.translation,
      word: q,
      transliteration: q,
      alternatives: apiResult.alternatives,
      source: apiResult.source,
      examples: context ? [{
        source: context,
        target: `[Translated context]`
      }] : []
    });
    return;
  }
  
  // Fallback to dictionary
  const translation = translationDict[word] || `[${q}]`;
  
  res.json({
    translation: translation,
    word: q,
    transliteration: q,
    alternatives: [translation],
    source: 'dictionary',
    examples: context ? [{
      source: context,
      target: `[Translated context]`
    }] : []
  });
});

app.post('/api/v2/translate', async (req, res) => {
  const { word, context, from, to } = req.body;
  
  const apiResult = await translateWithAPI(word, from, to);
  
  if (apiResult) {
    res.json({
      translation: apiResult.translation,
      word: word,
      transliteration: word,
      alternatives: apiResult.alternatives,
      source: apiResult.source
    });
    return;
  }
  
  const w = (word || '').toLowerCase().trim();
  const translation = translationDict[w] || `[${word}]`;
  
  res.json({
    translation: translation,
    word: word,
    transliteration: word,
    alternatives: [translation],
    source: 'dictionary'
  });
});

// ==================== USER WORD ENDPOINTS ====================

app.get('/api/userWords', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const userWords = Object.values(db.userWords)
    .filter(w => w.userId === db.currentUserId);
  
  res.json(userWords);
});

app.get('/api/userWord/:id', (req, res) => {
  const userWord = db.userWords[req.params.id];
  
  if (!userWord || userWord.userId !== db.currentUserId) {
    return res.status(404).json({ error: 'Not found' });
  }
  
  res.json(userWord);
});

app.post('/api/userWord', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const userWord = {
    id: req.body.id || generateId(),
    userId: db.currentUserId,
    word: req.body.word,
    translation: req.body.translation,
    language: req.body.language,
    contexts: req.body.contexts || [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    ...req.body
  };
  
  db.userWords[userWord.id] = userWord;
  saveData();
  
  res.json(userWord);
});

app.put('/api/userWord/:id', (req, res) => {
  const userWord = db.userWords[req.params.id];
  
  if (!userWord || userWord.userId !== db.currentUserId) {
    return res.status(404).json({ error: 'Not found' });
  }
  
  Object.assign(userWord, req.body, {
    updatedAt: new Date().toISOString()
  });
  
  db.userWords[userWord.id] = userWord;
  saveData();
  
  res.json(userWord);
});

app.delete('/api/userWord/:id', (req, res) => {
  const userWord = db.userWords[req.params.id];
  
  if (!userWord || userWord.userId !== db.currentUserId) {
    return res.status(404).json({ error: 'Not found' });
  }
  
  delete db.userWords[req.params.id];
  saveData();
  
  res.json({ success: true });
});

app.get('/api/userWordCounts', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const userWords = Object.values(db.userWords)
    .filter(w => w.userId === db.currentUserId);
  
  const counts = {};
  userWords.forEach(w => {
    counts[w.language] = (counts[w.language] || 0) + 1;
  });
  
  res.json(counts);
});

// ==================== LANGUAGE ENDPOINTS ====================

app.get('/api/languages', (req, res) => {
  const languages = [
    { code: 'en', name: 'English', direction: 'LTR' },
    { code: 'vi', name: 'Vietnamese', direction: 'LTR' },
    { code: 'es', name: 'Spanish', direction: 'LTR' },
    { code: 'fr', name: 'French', direction: 'LTR' },
    { code: 'de', name: 'German', direction: 'LTR' },
    { code: 'it', name: 'Italian', direction: 'LTR' },
    { code: 'pt', name: 'Portuguese', direction: 'LTR' },
    { code: 'ru', name: 'Russian', direction: 'LTR' },
    { code: 'zh', name: 'Chinese', direction: 'LTR' },
    { code: 'ja', name: 'Japanese', direction: 'LTR' },
    { code: 'ko', name: 'Korean', direction: 'LTR' },
    { code: 'ar', name: 'Arabic', direction: 'RTL' },
    { code: 'he', name: 'Hebrew', direction: 'RTL' },
    { code: 'hi', name: 'Hindi', direction: 'LTR' },
    { code: 'th', name: 'Thai', direction: 'LTR' },
    { code: 'tr', name: 'Turkish', direction: 'LTR' },
    { code: 'nl', name: 'Dutch', direction: 'LTR' },
    { code: 'pl', name: 'Polish', direction: 'LTR' },
    { code: 'sv', name: 'Swedish', direction: 'LTR' },
    { code: 'no', name: 'Norwegian', direction: 'LTR' }
  ];
  
  res.json(languages);
});

// ==================== OTHER ENDPOINTS ====================

app.get('/api/wordFrequency', (req, res) => {
  const { word, language } = req.query;
  
  res.json({
    word: word,
    language: language,
    frequency: Math.floor(Math.random() * 10000),
    rank: Math.floor(Math.random() * 50000)
  });
});

app.get('/api/shelves', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const shelves = Object.values(db.shelves)
    .filter(s => s.userId === db.currentUserId);
  
  res.json(shelves);
});

app.get('/api/shelf/:id', (req, res) => {
  const shelf = db.shelves[req.params.id];
  
  if (!shelf || shelf.userId !== db.currentUserId) {
    return res.status(404).json({ error: 'Not found' });
  }
  
  res.json(shelf);
});

app.get('/api/book/:id', (req, res) => {
  const book = db.books[req.params.id];
  
  if (!book) {
    return res.status(404).json({ error: 'Not found' });
  }
  
  res.json(book);
});

app.get('/api/chunk/:id', (req, res) => {
  const chunk = db.chunks[req.params.id];
  
  if (!chunk) {
    return res.status(404).json({ error: 'Not found' });
  }
  
  res.json(chunk);
});

app.get('/api/urls', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const urls = Object.values(db.urls)
    .filter(u => u.userId === db.currentUserId);
  
  res.json(urls);
});

app.get('/api/url', (req, res) => {
  const { url } = req.query;
  
  const savedUrl = Object.values(db.urls)
    .find(u => u.url === url && u.userId === db.currentUserId);
  
  if (savedUrl) {
    res.json(savedUrl);
  } else {
    res.status(404).json({ error: 'Not found' });
  }
});

app.get('/api/readyToStartFlashcards', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const { language } = req.query;
  const user = db.users[db.currentUserId];
  const targetLanguage = language || user.currentLearningLanguage;
  
  const userWords = Object.values(db.userWords)
    .filter(w => w.userId === db.currentUserId && w.language === targetLanguage);
  
  let countStarted = 0;
  let countReady = 0;
  
  userWords.forEach(w => {
    if (w.interval !== undefined) {
      countStarted++;
    } else {
      countReady++;
    }
  });
  
  res.json({
    ready: countReady > 0,
    countReady: countReady,
    countStarted: countStarted,
    total: userWords.length
  });
});

app.post('/api/splitTests/trackEvent/:eventName', (req, res) => {
  const { eventName } = req.params;
  const { properties } = req.body;
  
  console.log(`[Analytics] Event: ${eventName}`, properties);
  
  res.json({ success: true });
});

app.post('/api/experiment', (req, res) => {
  res.json({ success: true });
});

app.get('/api/webPushNotifications', (req, res) => {
  res.json([]);
});

app.delete('/api/webPushNotifications', (req, res) => {
  res.json({ success: true });
});

app.get('/api/tts', (req, res) => {
  const silentAudioBase64 = 'data:audio/mp3;base64,SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU4Ljc2LjEwMAAAAAAAAAAAAAAA//tQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAACAAADhAC7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u////////////////////////////////////////////////////////////////////wAAAABMYXZjNTguMTM0AAAAAAAAAAAAAAAAJAAAAAAAAAAAA4SFTHjVAAAAAAAAAAAAAAAAAAAA//sQZAAP8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAETEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV';
  
  res.send(silentAudioBase64);
});

app.get('/api/popularDomains', (req, res) => {
  res.json([
    { domain: 'wikipedia.org', count: 1000 },
    { domain: 'bbc.com', count: 500 },
    { domain: 'cnn.com', count: 450 },
    { domain: 'medium.com', count: 400 }
  ]);
});

app.get('/api/listAllWords', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const { language } = req.query;
  const userWords = Object.values(db.userWords)
    .filter(w => w.userId === db.currentUserId && (!language || w.language === language));
  
  res.json(userWords);
});

app.get('/api/dashboard', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const user = db.users[db.currentUserId];
  const userWords = Object.values(db.userWords)
    .filter(w => w.userId === db.currentUserId);
  
  res.json({
    user: user,
    stats: {
      totalWords: userWords.length,
      wordsToday: 0,
      streak: 0
    },
    recentActivity: []
  });
});

// ==================== ERROR HANDLER ====================

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal server error' });
});

// ==================== GRACEFUL SHUTDOWN ====================

process.on('SIGINT', () => {
  console.log('\n💾 Saving data before shutdown...');
  saveData();
  console.log('✅ Data saved. Goodbye!');
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\n💾 Saving data before shutdown...');
  saveData();
  console.log('✅ Data saved. Goodbye!');
  process.exit(0);
});

// ==================== START SERVER ====================

app.listen(PORT, () => {
  console.log(`
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║     Readlang Mock Server (Advanced) đang chạy!           ║
║                                                           ║
║         URL: http://localhost:${PORT}                      ║
║                                                           ║
║     ✨ Tính năng nâng cao:                                ║
║        - Lưu dữ liệu vĩnh viễn (data.json)               ║
║        - Tích hợp API dịch thuật thực (MyMemory)         ║
║        - Từ điển offline mở rộng (1000+ từ)              ║
║        - Auto-save mỗi 30 giây                           ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
  `);
  
  console.log('\n📊 Database Status:');
  console.log(`   Users: ${Object.keys(db.users).length}`);
  console.log(`   User Words: ${Object.keys(db.userWords).length}`);
  console.log(`   Current User: ${db.currentUserId}`);
  console.log(`   Data file: ${DATA_FILE}\n`);
  
  console.log('🌐 Translation Services:');
  console.log('   1. MyMemory API (online, free)');
  console.log('   2. Offline Dictionary (1000+ words)\n');
});
