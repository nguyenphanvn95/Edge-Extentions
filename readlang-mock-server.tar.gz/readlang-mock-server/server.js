const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// In-memory database
const db = {
  users: new Map(),
  userWords: new Map(),
  chunks: new Map(),
  books: new Map(),
  shelves: new Map(),
  urls: new Map(),
  currentUserId: null
};

// Helper functions
function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// Default user
const defaultUser = {
  id: 'user_default',
  email: 'offline@readlang.com',
  name: 'Offline User',
  firstLanguage: 'en',
  currentLearningLanguage: 'vi',
  readerDeselectBehavior: 'keep',
  readerMergePhrases: 'on',
  readerShowTransliteration: true,
  createdAt: new Date().toISOString(),
  premium: true
};

db.users.set(defaultUser.id, defaultUser);
db.currentUserId = defaultUser.id;

// ==================== AUTH ENDPOINTS ====================

app.get('/api/isAuthenticated', (req, res) => {
  if (db.currentUserId) {
    const user = db.users.get(db.currentUserId);
    res.json({
      authenticated: true,
      user: user
    });
  } else {
    res.json({ authenticated: false });
  }
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  
  // Simple mock login
  let user = Array.from(db.users.values()).find(u => u.email === email);
  
  if (!user) {
    user = {
      id: generateId(),
      email: email,
      name: email.split('@')[0],
      firstLanguage: 'en',
      currentLearningLanguage: 'vi',
      readerDeselectBehavior: 'keep',
      readerMergePhrases: 'on',
      readerShowTransliteration: true,
      createdAt: new Date().toISOString(),
      premium: true
    };
    db.users.set(user.id, user);
  }
  
  db.currentUserId = user.id;
  
  res.json({
    success: true,
    user: user,
    userWords: Array.from(db.userWords.values()).filter(w => w.userId === user.id)
  });
});

app.post('/api/logout', (req, res) => {
  db.currentUserId = null;
  res.json({ success: true });
});

app.post('/api/auth/googleSignIn', (req, res) => {
  const { idToken } = req.body;
  
  // Mock Google sign in
  const user = defaultUser;
  db.currentUserId = user.id;
  
  res.json({
    success: true,
    user: user
  });
});

// ==================== USER ENDPOINTS ====================

app.get('/api/user', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const user = db.users.get(db.currentUserId);
  res.json(user);
});

app.post('/api/user', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const user = db.users.get(db.currentUserId);
  const updates = req.body;
  
  Object.assign(user, updates);
  db.users.set(db.currentUserId, user);
  
  res.json(user);
});

app.put('/api/user', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const user = db.users.get(db.currentUserId);
  const updates = req.body;
  
  Object.assign(user, updates);
  db.users.set(db.currentUserId, user);
  
  res.json(user);
});

// ==================== TRANSLATION ENDPOINTS ====================

app.get('/api/translate', async (req, res) => {
  const { q, context, from, to } = req.query;
  
  // Mock translation - simple dictionary
  const translations = {
    // Vietnamese to English
    'xin chào': 'hello',
    'cảm ơn': 'thank you',
    'tạm biệt': 'goodbye',
    'vui lòng': 'please',
    'làm ơn': 'please',
    'xin lỗi': 'sorry',
    'tôi': 'I/me',
    'bạn': 'you',
    'chúng tôi': 'we',
    'họ': 'they',
    'này': 'this',
    'đó': 'that',
    'là': 'is/am/are',
    'có': 'have/has/there is',
    'không': 'no/not',
    'gì': 'what',
    'ai': 'who',
    'ở đâu': 'where',
    'khi nào': 'when',
    'tại sao': 'why',
    'như thế nào': 'how',
    
    // English to Vietnamese
    'hello': 'xin chào',
    'thank you': 'cảm ơn',
    'goodbye': 'tạm biệt',
    'please': 'vui lòng',
    'sorry': 'xin lỗi',
    'i': 'tôi',
    'me': 'tôi',
    'you': 'bạn',
    'we': 'chúng tôi',
    'they': 'họ',
    'this': 'này',
    'that': 'đó',
    'is': 'là',
    'am': 'là',
    'are': 'là',
    'have': 'có',
    'has': 'có',
    'no': 'không',
    'not': 'không',
    'what': 'gì',
    'who': 'ai',
    'where': 'ở đâu',
    'when': 'khi nào',
    'why': 'tại sao',
    'how': 'như thế nào'
  };
  
  const word = (q || '').toLowerCase().trim();
  const translation = translations[word] || `[Translation of "${q}"]`;
  
  res.json({
    translation: translation,
    word: q,
    transliteration: q, // Mock transliteration
    alternatives: [translation],
    examples: [
      {
        source: context || `Example with ${q}`,
        target: `Ví dụ với ${translation}`
      }
    ]
  });
});

// ==================== USER WORD ENDPOINTS ====================

app.get('/api/userWords', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const userWords = Array.from(db.userWords.values())
    .filter(w => w.userId === db.currentUserId);
  
  res.json(userWords);
});

app.get('/api/userWord/:id', (req, res) => {
  const userWord = db.userWords.get(req.params.id);
  
  if (!userWord || userWord.userId !== db.currentUserId) {
    return res.status(404).json({ error: 'Not found' });
  }
  
  res.json(userWord);
});

app.post('/api/userWord', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const userWord = {
    id: req.body.id || generateId(),
    userId: db.currentUserId,
    word: req.body.word,
    translation: req.body.translation,
    language: req.body.language,
    contexts: req.body.contexts || [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    ...req.body
  };
  
  db.userWords.set(userWord.id, userWord);
  
  res.json(userWord);
});

app.put('/api/userWord/:id', (req, res) => {
  const userWord = db.userWords.get(req.params.id);
  
  if (!userWord || userWord.userId !== db.currentUserId) {
    return res.status(404).json({ error: 'Not found' });
  }
  
  Object.assign(userWord, req.body, {
    updatedAt: new Date().toISOString()
  });
  
  db.userWords.set(userWord.id, userWord);
  
  res.json(userWord);
});

app.delete('/api/userWord/:id', (req, res) => {
  const userWord = db.userWords.get(req.params.id);
  
  if (!userWord || userWord.userId !== db.currentUserId) {
    return res.status(404).json({ error: 'Not found' });
  }
  
  db.userWords.delete(req.params.id);
  
  res.json({ success: true });
});

app.get('/api/userWordCounts', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const userWords = Array.from(db.userWords.values())
    .filter(w => w.userId === db.currentUserId);
  
  const counts = {};
  userWords.forEach(w => {
    counts[w.language] = (counts[w.language] || 0) + 1;
  });
  
  res.json(counts);
});

// ==================== LANGUAGE ENDPOINTS ====================

app.get('/api/languages', (req, res) => {
  const languages = [
    { code: 'en', name: 'English', direction: 'LTR' },
    { code: 'vi', name: 'Vietnamese', direction: 'LTR' },
    { code: 'es', name: 'Spanish', direction: 'LTR' },
    { code: 'fr', name: 'French', direction: 'LTR' },
    { code: 'de', name: 'German', direction: 'LTR' },
    { code: 'it', name: 'Italian', direction: 'LTR' },
    { code: 'pt', name: 'Portuguese', direction: 'LTR' },
    { code: 'ru', name: 'Russian', direction: 'LTR' },
    { code: 'zh', name: 'Chinese', direction: 'LTR' },
    { code: 'ja', name: 'Japanese', direction: 'LTR' },
    { code: 'ko', name: 'Korean', direction: 'LTR' },
    { code: 'ar', name: 'Arabic', direction: 'RTL' },
    { code: 'he', name: 'Hebrew', direction: 'RTL' },
    { code: 'hi', name: 'Hindi', direction: 'LTR' },
    { code: 'th', name: 'Thai', direction: 'LTR' },
    { code: 'tr', name: 'Turkish', direction: 'LTR' }
  ];
  
  res.json(languages);
});

// ==================== WORD FREQUENCY ENDPOINTS ====================

app.get('/api/wordFrequency', (req, res) => {
  const { word, language } = req.query;
  
  // Mock frequency data
  res.json({
    word: word,
    language: language,
    frequency: Math.floor(Math.random() * 10000),
    rank: Math.floor(Math.random() * 50000)
  });
});

// ==================== BOOK/SHELF ENDPOINTS ====================

app.get('/api/shelves', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const shelves = Array.from(db.shelves.values())
    .filter(s => s.userId === db.currentUserId);
  
  res.json(shelves);
});

app.get('/api/shelf/:id', (req, res) => {
  const shelf = db.shelves.get(req.params.id);
  
  if (!shelf || shelf.userId !== db.currentUserId) {
    return res.status(404).json({ error: 'Not found' });
  }
  
  res.json(shelf);
});

app.get('/api/book/:id', (req, res) => {
  const book = db.books.get(req.params.id);
  
  if (!book) {
    return res.status(404).json({ error: 'Not found' });
  }
  
  res.json(book);
});

app.get('/api/chunk/:id', (req, res) => {
  const chunk = db.chunks.get(req.params.id);
  
  if (!chunk) {
    return res.status(404).json({ error: 'Not found' });
  }
  
  res.json(chunk);
});

// ==================== URL ENDPOINTS ====================

app.get('/api/urls', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const urls = Array.from(db.urls.values())
    .filter(u => u.userId === db.currentUserId);
  
  res.json(urls);
});

app.get('/api/url', (req, res) => {
  const { url } = req.query;
  
  const savedUrl = Array.from(db.urls.values())
    .find(u => u.url === url && u.userId === db.currentUserId);
  
  if (savedUrl) {
    res.json(savedUrl);
  } else {
    res.status(404).json({ error: 'Not found' });
  }
});

// ==================== FLASHCARD ENDPOINTS ====================

app.get('/api/readyToStartFlashcards', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const { language } = req.query;
  const user = db.users.get(db.currentUserId);
  const targetLanguage = language || user.currentLearningLanguage;
  
  const userWords = Array.from(db.userWords.values())
    .filter(w => w.userId === db.currentUserId && w.language === targetLanguage);
  
  let countStarted = 0;
  let countReady = 0;
  
  userWords.forEach(w => {
    if (w.interval !== undefined) {
      countStarted++;
    } else {
      countReady++;
    }
  });
  
  res.json({
    ready: countReady > 0,
    countReady: countReady,
    countStarted: countStarted,
    total: userWords.length
  });
});

// ==================== SPLIT TESTS / ANALYTICS ====================

app.post('/api/splitTests/trackEvent/:eventName', (req, res) => {
  const { eventName } = req.params;
  const { properties } = req.body;
  
  console.log(`[Analytics] Event: ${eventName}`, properties);
  
  res.json({ success: true });
});

app.post('/api/experiment', (req, res) => {
  res.json({ success: true });
});

// ==================== WEB PUSH NOTIFICATIONS ====================

app.get('/api/webPushNotifications', (req, res) => {
  res.json([]);
});

app.delete('/api/webPushNotifications', (req, res) => {
  res.json({ success: true });
});

// ==================== TTS (Text-to-Speech) ====================

app.get('/api/tts', (req, res) => {
  const { text, language } = req.query;
  
  // Return a mock audio file (silent audio in base64)
  const silentAudioBase64 = 'data:audio/mp3;base64,SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU4Ljc2LjEwMAAAAAAAAAAAAAAA//tQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAACAAADhAC7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u////////////////////////////////////////////////////////////////////wAAAABMYXZjNTguMTM0AAAAAAAAAAAAAAAAJAAAAAAAAAAAA4SFTHjVAAAAAAAAAAAAAAAAAAAA//sQZAAP8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAETEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV';
  
  res.send(silentAudioBase64);
});

// ==================== POPULAR DOMAINS ====================

app.get('/api/popularDomains', (req, res) => {
  res.json([
    { domain: 'wikipedia.org', count: 1000 },
    { domain: 'bbc.com', count: 500 },
    { domain: 'cnn.com', count: 450 },
    { domain: 'medium.com', count: 400 }
  ]);
});

// ==================== LIST ALL WORDS ====================

app.get('/api/listAllWords', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const { language } = req.query;
  const userWords = Array.from(db.userWords.values())
    .filter(w => w.userId === db.currentUserId && (!language || w.language === language));
  
  res.json(userWords);
});

// ==================== DASHBOARD ====================

app.get('/api/dashboard', (req, res) => {
  if (!db.currentUserId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const user = db.users.get(db.currentUserId);
  const userWords = Array.from(db.userWords.values())
    .filter(w => w.userId === db.currentUserId);
  
  res.json({
    user: user,
    stats: {
      totalWords: userWords.length,
      wordsToday: 0,
      streak: 0
    },
    recentActivity: []
  });
});

// ==================== V2 API ====================

app.post('/api/v2/translate', async (req, res) => {
  const { word, context, from, to } = req.body;
  
  // Use the same translation logic as GET /api/translate
  const translations = {
    'xin chào': 'hello',
    'cảm ơn': 'thank you',
    'hello': 'xin chào',
    'thank you': 'cảm ơn'
  };
  
  const w = (word || '').toLowerCase().trim();
  const translation = translations[w] || `[Translation of "${word}"]`;
  
  res.json({
    translation: translation,
    word: word,
    transliteration: word,
    alternatives: [translation]
  });
});

// ==================== ERROR HANDLER ====================

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal server error' });
});

// ==================== START SERVER ====================

app.listen(PORT, () => {
  console.log(`
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║         Readlang Mock Server đang chạy!                  ║
║                                                           ║
║         URL: http://localhost:${PORT}                      ║
║                                                           ║
║         Để sử dụng với extension:                        ║
║         1. Mở background.js                               ║
║         2. Đổi environment = "local"                      ║
║         3. Load extension vào Chrome                      ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
  `);
  
  console.log('\n📊 Database Status:');
  console.log(`   Users: ${db.users.size}`);
  console.log(`   User Words: ${db.userWords.size}`);
  console.log(`   Current User: ${db.currentUserId}\n`);
  
  console.log('🔌 Available Endpoints:');
  console.log('   GET  /api/isAuthenticated');
  console.log('   POST /api/login');
  console.log('   POST /api/logout');
  console.log('   GET  /api/user');
  console.log('   GET  /api/translate?q=word&from=en&to=vi');
  console.log('   GET  /api/languages');
  console.log('   GET  /api/userWords');
  console.log('   POST /api/userWord');
  console.log('   ... và nhiều endpoints khác\n');
});
