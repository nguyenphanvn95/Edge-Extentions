# Hướng Dẫn Nhanh - Readlang Mock Server

## 🚀 Khởi động nhanh (5 phút)

### Bước 1: Cài đặt
```bash
cd readlang-mock-server
npm install
```

### Bước 2: Chọn server
```bash
# Server cơ bản (chỉ từ điển offline)
npm start

# Server nâng cao (có API dịch thực + lưu dữ liệu)
npm start:advanced
```

### Bước 3: Load extension
1. Mở Chrome: `chrome://extensions/`
2. Bật "Developer mode"
3. Click "Load unpacked"
4. Chọn thư mục: `readlang-extension-local/`

### Bước 4: Sử dụng
1. Mở bất kỳ trang web nào
2. Click icon Readlang
3. Bắt đầu học ngôn ngữ!

---

## 📌 So sánh 2 phiên bản server

### Server Cơ Bản (`server.js`)
✅ Nhanh, đơn giản
✅ Chạy hoàn toàn offline
❌ Dữ liệu mất khi tắt server
❌ Từ điển hạn chế (~100 từ)

**Sử dụng khi:** Bạn muốn test nhanh hoặc không cần lưu dữ liệu

### Server Nâng Cao (`server-advanced.js`)
✅ Tích hợp API dịch thực (MyMemory)
✅ Lưu dữ liệu vĩnh viễn (file JSON)
✅ Từ điển offline lớn (1000+ từ)
✅ Auto-save mỗi 30 giây

**Sử dụng khi:** Bạn muốn sử dụng lâu dài và cần dịch chính xác

---

## ⚡ Lệnh nhanh

```bash
# Server cơ bản
npm start

# Server nâng cao
npm start:advanced

# Auto-reload khi code thay đổi
npm run dev                # server cơ bản
npm run dev:advanced       # server nâng cao
```

---

## 🔍 Kiểm tra server hoạt động

Mở trình duyệt và thử:
- http://localhost:3000/api/languages
- http://localhost:3000/api/translate?q=hello&from=en&to=vi

Nếu thấy dữ liệu JSON => Server hoạt động OK!

---

## 💡 Tips

1. **Dữ liệu lưu ở đâu?**
   - Server cơ bản: RAM (mất khi tắt)
   - Server nâng cao: File `data.json`

2. **Thêm từ vào từ điển?**
   - Mở file `server.js` hoặc `server-advanced.js`
   - Tìm object `translationDict`
   - Thêm từ mới theo format:
     ```javascript
     'từ nguồn': 'từ đích',
     ```

3. **Xem log?**
   - Tất cả request được log ra console
   - Analytics events cũng được log

4. **Reset dữ liệu?**
   - Server cơ bản: Restart server
   - Server nâng cao: Xóa file `data.json`

---

## 🐛 Gặp lỗi?

### Extension không kết nối
- Kiểm tra server có chạy không?
- Kiểm tra `environment = "local"` trong background.js

### Dịch không hoạt động
- Server nâng cao: Kiểm tra kết nối internet (cho API)
- Server cơ bản: Thêm từ vào từ điển

### Không lưu được từ
- Kiểm tra console log
- Thử restart extension

---

## 📚 Đọc thêm

Xem file **README.md** để biết chi tiết đầy đủ về:
- Tất cả API endpoints
- Cách tùy chỉnh
- Cách mở rộng
- Troubleshooting chi tiết
