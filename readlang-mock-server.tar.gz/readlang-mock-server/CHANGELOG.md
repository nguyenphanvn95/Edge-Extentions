# Changelog

## Version 1.0.0 (2024-02-10)

### ✨ Tính năng

#### Server Cơ Bản (`server.js`)
- ✅ Hỗ trợ đầy đủ các API endpoints của Readlang
- ✅ Authentication (login, logout, Google sign-in)
- ✅ User management
- ✅ Từ điển dịch thuật cơ bản (~100 từ phổ biến)
- ✅ Quản lý từ vựng (CRUD operations)
- ✅ Flashcards tracking
- ✅ Analytics & event tracking
- ✅ Multi-language support (16 ngôn ngữ)

#### Server Nâng Cao (`server-advanced.js`)
- ✅ Tất cả tính năng của server cơ bản
- ✅ Tích hợp MyMemory Translation API (miễn phí)
- ✅ Fallback sang offline dictionary khi API fail
- ✅ Lưu trữ dữ liệu vĩnh viễn (file JSON)
- ✅ Auto-save mỗi 30 giây
- ✅ Graceful shutdown (lưu data trước khi tắt)
- ✅ Từ điển offline mở rộng (1000+ từ)
- ✅ Hỗ trợ Vietnamese ↔ English

#### Extension
- ✅ Extension đã được patch để hoạt động ở local mode
- ✅ Tương thích hoàn toàn với Chrome/Edge
- ✅ Manifest V3 compliant

### 📦 Package
- Express.js 4.18.2
- CORS enabled
- Body parser middleware
- Error handling
- Logging

### 📖 Documentation
- README.md đầy đủ
- QUICKSTART.md cho người mới
- Inline comments trong code
- API documentation

### 🔧 Development Tools
- Setup script (bash)
- npm scripts for easy start
- nodemon support for auto-reload

---

## Roadmap

### Version 1.1.0 (Planned)
- [ ] SQLite database integration
- [ ] Import/export user data
- [ ] Web dashboard for data management
- [ ] More translation APIs (Google, DeepL)
- [ ] Audio pronunciation (real TTS)
- [ ] Example sentences from real sources
- [ ] Word frequency from corpus
- [ ] Spaced repetition algorithm

### Version 1.2.0 (Planned)
- [ ] Multi-user support
- [ ] Sync across devices
- [ ] Docker support
- [ ] RESTful API documentation (Swagger)
- [ ] GraphQL endpoint
- [ ] WebSocket for real-time updates

---

## Known Issues

1. TTS returns silent audio (mock)
   - Workaround: None yet
   - Planned: Integrate real TTS API

2. Translation limited to dictionary entries (basic server)
   - Workaround: Use advanced server
   - Solution: MyMemory API in advanced server

3. No user authentication
   - Impact: Single user only
   - Planned: Multi-user in v1.2.0

---

## Contributing

Contributions are welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

---

## Credits

- Original Readlang extension: readlang.com
- MyMemory Translation API: mymemory.translated.net
- Express.js framework
- Community contributors

---

## License

MIT License - See LICENSE file for details
