#!/bin/bash

echo "═══════════════════════════════════════════════════════════"
echo "        Readlang Mock Server - Quick Setup Script          "
echo "═══════════════════════════════════════════════════════════"
echo ""

# Kiểm tra Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js chưa được cài đặt!"
    echo "   Vui lòng cài đặt Node.js từ: https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js version: $(node --version)"
echo ""

# Cài đặt dependencies
echo "📦 Đang cài đặt dependencies..."
npm install

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Cài đặt thành công!"
    echo ""
    echo "═══════════════════════════════════════════════════════════"
    echo "                    HƯỚNG DẪN SỬ DỤNG                      "
    echo "═══════════════════════════════════════════════════════════"
    echo ""
    echo "1️⃣  Khởi động server:"
    echo "   npm start"
    echo ""
    echo "2️⃣  Load extension vào Chrome:"
    echo "   - Mở chrome://extensions/"
    echo "   - Bật 'Developer mode'"
    echo "   - Click 'Load unpacked'"
    echo "   - Chọn thư mục: readlang-extension-local/"
    echo ""
    echo "3️⃣  Sử dụng:"
    echo "   - Mở một trang web bất kỳ"
    echo "   - Click icon Readlang để bắt đầu"
    echo ""
    echo "📖 Xem thêm chi tiết trong README.md"
    echo ""
    echo "═══════════════════════════════════════════════════════════"
else
    echo ""
    echo "❌ Cài đặt thất bại!"
    echo "   Vui lòng kiểm tra lại Node.js và npm"
fi
