# Readlang Mock Server - Offline Mode

Mock server để chạy Readlang Chrome Extension ở chế độ offline với đầy đủ chức năng.

## 🚀 Cài đặt

### 1. Cài đặt dependencies

```bash
cd readlang-mock-server
npm install
```

### 2. Chạy server

```bash
npm start
```

Hoặc để tự động reload khi có thay đổi:

```bash
npm run dev
```

Server sẽ chạy tại: **http://localhost:3000**

## 🔧 Cấu hình Extension

### Cách 1: Chỉnh sửa trực tiếp extension

1. Mở file `src/background.js` trong thư mục extension
2. Tìm dòng:
   ```javascript
   const environment = "prod";
   ```
3. Đổi thành:
   ```javascript
   const environment = "local";
   ```
4. Lưu file

### Cách 2: Sử dụng extension đã được patch (khuyến nghị)

Tôi đã tạo sẵn một bản extension đã được cấu hình cho local mode trong thư mục `readlang-extension-local/`

## 📦 Load Extension vào Chrome

1. Mở Chrome và truy cập: `chrome://extensions/`
2. Bật "Developer mode" (góc trên bên phải)
3. Click "Load unpacked"
4. Chọn thư mục `readlang-extension-local/` (hoặc thư mục extension gốc nếu bạn đã chỉnh sửa)
5. Extension sẽ xuất hiện trong danh sách

## ✅ Kiểm tra hoạt động

1. Đảm bảo server đang chạy (`npm start`)
2. Mở một trang web bất kỳ
3. Click vào icon Readlang trên thanh công cụ Chrome
4. Web Reader sẽ xuất hiện và kết nối với local server

## 🎯 Các tính năng được hỗ trợ

### ✅ Hoàn toàn hoạt động offline:

- ✅ **Dịch từ/cụm từ**: Click vào từ để dịch
- ✅ **Lưu từ vựng**: Tự động lưu các từ đã dịch
- ✅ **Quản lý từ vựng**: Xem, chỉnh sửa, xóa từ
- ✅ **Nhiều ngôn ngữ**: Hỗ trợ 16+ ngôn ngữ
- ✅ **Flashcards**: Ôn tập từ vựng
- ✅ **Import văn bản**: Import từ trang web
- ✅ **Context menu**: Right-click để import
- ✅ **Tần suất từ**: Hiển thị độ phổ biến của từ
- ✅ **Cài đặt người dùng**: Tùy chỉnh ngôn ngữ, hành vi

### 📝 Lưu ý:

- Dữ liệu chỉ lưu trong RAM, sẽ mất khi tắt server
- Dịch thuật sử dụng từ điển đơn giản (có thể mở rộng)
- TTS (Text-to-Speech) trả về file audio im lặng (mock)

## 🔧 Cấu trúc API

Server mock các endpoints chính:

### Authentication
- `GET /api/isAuthenticated` - Kiểm tra trạng thái đăng nhập
- `POST /api/login` - Đăng nhập
- `POST /api/logout` - Đăng xuất
- `POST /api/auth/googleSignIn` - Đăng nhập Google

### User Management  
- `GET /api/user` - Lấy thông tin user
- `POST /api/user` - Cập nhật user
- `PUT /api/user` - Cập nhật user

### Translation
- `GET /api/translate?q=word&from=en&to=vi` - Dịch từ
- `POST /api/v2/translate` - Dịch từ (v2)

### User Words (Từ vựng)
- `GET /api/userWords` - Lấy tất cả từ vựng
- `POST /api/userWord` - Thêm từ mới
- `PUT /api/userWord/:id` - Cập nhật từ
- `DELETE /api/userWord/:id` - Xóa từ
- `GET /api/userWordCounts` - Thống kê từ vựng

### Languages
- `GET /api/languages` - Danh sách ngôn ngữ hỗ trợ

### Flashcards
- `GET /api/readyToStartFlashcards` - Kiểm tra flashcards sẵn sàng

### Other
- `GET /api/wordFrequency` - Tần suất từ
- `GET /api/tts` - Text-to-speech
- `POST /api/splitTests/trackEvent/:eventName` - Analytics

## 🎨 Tùy chỉnh

### Thêm từ điển dịch thuật

Mở `server.js` và chỉnh sửa object `translations` trong endpoint `/api/translate`:

```javascript
const translations = {
  // Thêm từ của bạn ở đây
  'từ tiếng việt': 'english translation',
  'english word': 'bản dịch tiếng việt',
  // ...
};
```

### Thêm ngôn ngữ mới

Chỉnh sửa endpoint `/api/languages`:

```javascript
const languages = [
  { code: 'xx', name: 'Language Name', direction: 'LTR' },
  // direction có thể là 'LTR' (trái sang phải) hoặc 'RTL' (phải sang trái)
];
```

### Lưu dữ liệu vĩnh viễn

Để lưu dữ liệu giữa các lần chạy server, bạn có thể:

1. **Sử dụng SQLite**: Thay thế `db` object bằng SQLite database
2. **Sử dụng JSON file**: Lưu/load data từ file JSON
3. **Sử dụng MongoDB**: Kết nối với MongoDB local

## 🐛 Troubleshooting

### Extension không kết nối được với server

1. Kiểm tra server có đang chạy không: `http://localhost:3000/api/languages`
2. Kiểm tra `environment` trong `background.js` đã là `"local"` chưa
3. Kiểm tra Chrome DevTools > Console để xem lỗi

### Dịch không hoạt động

1. Kiểm tra endpoint `/api/translate` có hoạt động không
2. Thêm từ vào từ điển trong `server.js`
3. Xem console log của server để debug

### Extension bị lỗi sau khi load

1. Xóa extension và load lại
2. Kiểm tra file manifest.json có hợp lệ không
3. Restart Chrome

## 📚 Mở rộng

### Tích hợp dịch thuật thực

Bạn có thể tích hợp các API dịch thuật như:

- Google Translate API
- DeepL API
- Microsoft Translator
- MyMemory Translation API (free)

Ví dụ với MyMemory (free, không cần API key):

```javascript
app.get('/api/translate', async (req, res) => {
  const { q, from, to } = req.query;
  
  const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(q)}&langpair=${from}|${to}`;
  
  try {
    const response = await fetch(url);
    const data = await response.json();
    
    res.json({
      translation: data.responseData.translatedText,
      word: q,
      alternatives: data.matches?.map(m => m.translation) || []
    });
  } catch (error) {
    res.status(500).json({ error: 'Translation failed' });
  }
});
```

### Thêm database

Ví dụ với SQLite:

```bash
npm install better-sqlite3
```

```javascript
const Database = require('better-sqlite3');
const db = new Database('readlang.db');

// Tạo tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT,
    name TEXT,
    settings TEXT
  );
  
  CREATE TABLE IF NOT EXISTS user_words (
    id TEXT PRIMARY KEY,
    user_id TEXT,
    word TEXT,
    translation TEXT,
    language TEXT,
    created_at TEXT
  );
`);
```

## 📝 License

MIT

## 🤝 Contributing

Mọi đóng góp đều được chào đón! Hãy tạo issue hoặc pull request.

## ⚠️ Disclaimer

Đây là mock server cho mục đích học tập và phát triển offline. Không sử dụng cho mục đích thương mại.
